import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Extract sign, exponent, and mantissa from the input
  val sign = io.a(3)
  val exponent = io.a(2, 1)
  val mantissa = io.a(0)

  // Decode the E2M1 code into a fixed-point number
  val decodedValue = MuxCase(0.S(5.W), Array(
    (exponent === 0.U && mantissa === 0.U) -> 0.S(5.W),  // +0 and -0
    (exponent === 0.U && mantissa === 1.U) -> 1.S(5.W),  // 0.5
    (exponent === 1.U && mantissa === 0.U) -> 2.S(5.W),  // 1.0
    (exponent === 1.U && mantissa === 1.U) -> 3.S(5.W),  // 1.5
    (exponent === 2.U && mantissa === 0.U) -> 4.S(5.W),  // 2.0
    (exponent === 2.U && mantissa === 1.U) -> 6.S(5.W),  // 3.0
    (exponent === 3.U && mantissa === 0.U) -> 8.S(5.W)   // 4.0
  ))

  // Apply the sign to the decoded value
  io.y := Mux(sign === 0.U, decodedValue, -decodedValue)
}