package cand_E2M1Decode_final

import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Lookup table for E2M1 to SInt(5.W) conversion
  private val decodeTable = VecInit(Seq(
    0.S, 1.S, 2.S, 3.S, 4.S, 6.S, 8.S, 12.S,
    0.S, -1.S, -2.S, -3.S, -4.S, -6.S, -8.S, -12.S
  ))

  // Extract sign, exponent, and mantissa
  val sign = io.a(3)
  val exponent = io.a(2, 1)
  val mantissa = io.a(0)

  // Create an index for the lookup table
  val index = Cat(sign, exponent, mantissa)

  // Decode using the lookup table
  val decodedValue = decodeTable(index)

  // Output the decoded value
  io.y := decodedValue
}