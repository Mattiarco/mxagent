import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Define constants
  val NaN = "b11111111100000000000000000000000".U
  val SUBNORMAL = "b00000000000000000000000001000000".U

  // Handle NaN case
  val isNaN = io.x === "b11111111".U
  val resultNaN = Mux(isNaN, NaN, 0.U)

  // Handle SUBNORMAL case
  val isSubnormal = io.x === 0.U
  val resultSubnormal = Mux(isSubnormal, SUBNORMAL, 0.U)

  // Calculate exponent for normal numbers
  val exponent = io.x - 127.U
  val exponentBits = exponent.asSInt + 127.S  // Convert to IEEE-754 exponent

  // Handle normal numbers
  val isNormal = ~isNaN & ~isSubnormal
  val resultNormal = Mux(isNormal, Cat(exponentBits.asUInt, 0.U(23.W)), 0.U)

  // Final result
  io.y := Mux(isNaN, NaN, Mux(isSubnormal, SUBNORMAL, resultNormal))
}