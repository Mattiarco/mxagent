import chisel3._
import chisel3.util._
import chisel3.experimental.FlatIO

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Constants
  val NaN = "b11111111000000000000000000000000".U
  val Inf = "b01111111100000000000000000000000".U
  val NegInf = "b11111111100000000000000000000000".U
  val Zero = "b00000000000000000000000000000000".U
  val NegZero = "b10000000000000000000000000000000".U

  // Check for NaN inputs
  when (io.a_scale === 0xFF.U || io.b_scale === 0xFF.U) {
    io.y := NaN
  } .otherwise {
    // Extract elements from a and b
    val a_elements = Seq.fill(32) { i => io.a((4 * i + 3, 4 * i)) }
    val b_elements = Seq.fill(32) { i => io.b((4 * i + 3, 4 * i)) }

    // Compute the dot product
    val dot_product = a_elements.zip(b_elements).map { case (a_elem, b_elem) =>
      // Convert FP4 E2M1 to binary32
      val a_val = Cat(0.U(1.W), a_elem, 0.U(23.W)) // 1.0 * a_elem * 2^2
      val b_val = Cat(0.U(1.W), b_elem, 0.U(23.W)) // 1.0 * b_elem * 2^2

      // Multiply the two values
      a_val.asSInt * b_val.asSInt
    }.reduce(_ + _)

    // Scale the dot product
    val scale_a = io.a_scale.asSInt - 127
    val scale_b = io.b_scale.asSInt - 127
    val total_scale = scale_a + scale_b

    // Adjust the dot product for the total scale
    val scaled_dot_product = dot_product >> total_scale

    // Convert the scaled dot product to binary32
    val result = scaled_dot_product.asUInt

    // Handle overflow and underflow
    when (scaled_dot_product > 0x7FE00000.U) {
      io.y := Inf
    } .elsewhen (scaled_dot_product < -0x7FE00000.U) {
      io.y := NegInf
    } .elsewhen (scaled_dot_product === 0.U) {
      io.y := Zero
    } .elsewhen (scaled_dot_product === -1.U) {
      io.y := NegZero
    } .otherwise {
      io.y := result
    }
  }
}