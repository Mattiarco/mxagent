import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Define constants
  val nanValue = "b01111111100000000000000000000000".U(32.W)
  val subnormalValue = "b00000000000000000000000000100000".U(32.W)
  val exponentBias = 127

  // Handle NaN case
  val isNaN = io.x === "b11111111".U
  val isSubnormal = io.x === 0.U

  // Calculate the exponent for normal numbers
  val exponent = (io.x.asSInt - exponentBias).asSInt + 127
  val exponentBits = exponent.asUInt(8.W)

  // Construct the output for normal numbers
  val normalValue = Cat(exponentBits, Fill(23, 0.U))

  // Select the output based on the input value
  io.y := Mux(isNaN, nanValue,
           Mux(isSubnormal, subnormalValue,
               normalValue))
}