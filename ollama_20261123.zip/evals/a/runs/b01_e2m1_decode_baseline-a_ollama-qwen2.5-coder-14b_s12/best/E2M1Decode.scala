import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Extract the sign, exponent, and mantissa from the input
  val sign = io.a(3)
  val exponent = io.a(2, 1)
  val mantissa = io.a(0)

  // Decode the E2M1 format to get the integer value
  val value = Mux(exponent === 0.U, 0.S, (Cat(exponent, mantissa) + 1.S) << (exponent - 1.U))

  // Apply the sign and multiply by 2
  io.y := Mux(sign === 0.U, value << 1.U, -value << 1.U)
}