import chisel3._
import chisel3.util._
import chisel3.experimental.FlatIO

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed (element i at bits [32*i+31:32*i]). 32 binary32 values
    val scale = Output(UInt(8.W))    // E8M0 scale code. shared scale X
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). quantized elements
  })

  // Helper function to extract a 32-bit element from the input vector
  def getElement(input: UInt, index: Int): UInt = {
    input((index + 1) * 32 - 1, index * 32)
  }

  // Helper function to check if a binary32 value is NaN or Inf
  def isNaNOrInf(value: UInt): Bool = {
    val exponent = value(30, 23)
    val mantissa = value(22, 0)
    (exponent === "b11111111".U) && (mantissa.orR)
  }

  // Helper function to compute the floor(log2) of a binary32 value
  def floorLog2(value: UInt): Int = {
    val exponent = value(30, 23)
    if (exponent === "b00000000".U) {
      // Subnormal number
      val leadingOnePos = (32.U - leadingZeros(value(22, 0)) - 1).asSInt
      leadingOnePos - 126
    } else {
      // Normal number
      exponent.asSInt - 127
    }
  }

  // Compute the shared exponent
  val maxLog2 = Wire(SInt(8.W))
  val allZero = Wire(Bool())
  val anyNaNOrInf = Wire(Bool())

  allZero := true.B
  anyNaNOrInf := false.B
  maxLog2 := -127.S

  for (i <- 0 until 32) {
    val element = getElement(io.x, i)
    val isNaNOrInf_i = isNaNOrInf(element)
    val log2_i = floorLog2(element)

    allZero := allZero && (element === 0.U)
    anyNaNOrInf := anyNaNOrInf || isNaNOrInf_i

    when (element =/= 0.U && !isNaNOrInf_i) {
      maxLog2 := Mux(log2_i > maxLog2, log2_i, maxLog2)
    }
  }

  val shared = Mux(anyNaNOrInf, -128.S, Mux(allZero, -127.S, maxLog2 - 2.S))
  val scale = (shared + 127.S).asUInt

  // Quantize each element
  val q = Wire(Vec(32, UInt(4.W)))

  for (i <- 0 until 32) {
    val element = getElement(io.x, i)
    val sign = element(31)
    val isNaNOrInf_i = isNaNOrInf(element)

    q(i) := Mux(isNaNOrInf_i || allZero, 0.U,
      Mux(sign, "b1000".U, "b0000".U)
    )
  }

  io.scale := scale
  io.q := q.asUInt
}