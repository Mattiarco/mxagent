package cand_it00

import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Extract components from the E2M1 input
  val sign = io.a(3)
  val exponent = io.a(2, 1)
  val mantissa = io.a(0)

  // Calculate the value based on the E2M1 format
  val value = Mux(exponent === 0.U, mantissa.asSInt, (mantissa + 1.U) << exponent)

  // Apply the sign
  val signedValue = Mux(sign === 0.U, value, -value)

  // Output the result multiplied by 2
  io.y := signedValue << 1
}