import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Define constants
  val NaN = "b11111111100000000000000000000000".U(32.W)
  val SUBNORMAL = "b00000000000000000000000001000000".U(32.W)

  // Handle NaN case
  when (io.x === 0xFF.U) {
    io.y := NaN
  } .elsewhen (io.x === 0.U) {
    // Handle subnormal case
    io.y := SUBNORMAL
  } .otherwise {
    // Handle normal numbers
    val exponent = io.x - 127.U
    val biasedExponent = exponent + 127.U
    io.y := Cat(biasedExponent, 0.U(23.W))
  }
}