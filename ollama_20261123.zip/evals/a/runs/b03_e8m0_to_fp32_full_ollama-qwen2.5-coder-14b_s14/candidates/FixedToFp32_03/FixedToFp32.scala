import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Parameters
  val w = 14
  val frac = 2

  // Helper function to calculate the absolute value of a signed integer
  private def abs(x: SInt): SInt = Mux(x < 0.S, -x, x)

  // Calculate the effective exponent
  val effectiveExp = io.exp - frac.asSInt

  // Calculate the absolute value of the input fixed-point number
  val absX = abs(io.x)

  // Calculate the unbiased exponent
  val unbiasedExp = effectiveExp + 127.S

  // Calculate the significand bits
  val significandBits = absX << (23 - w).asUInt

  // Calculate the significand with rounding
  val roundedSignificand = significandBits + (1 << (22 - w)).asUInt
  val significand = (roundedSignificand >> (22 - w)).asUInt

  // Handle overflow to infinity
  val overflow = unbiasedExp >= 255.S

  // Handle underflow to subnormal
  val underflow = unbiasedExp < 0.S

  // Handle exact zero
  val exactZero = io.x === 0.S

  // Handle NaN
  val isNaN = io.nan

  // Determine the final exponent
  val finalExp = Mux(overflow, 255.U, Mux(underflow, 0.U, unbiasedExp.asUInt))

  // Determine the final significand
  val finalSignificand = Mux(overflow || underflow, 0.U, significand)

  // Determine the final result
  val result = WireDefault(0.U(32.W))

  when (isNaN) {
    result := "b11111111100000000000000000000000".U
  }.elsewhen (exactZero) {
    result := 0.U
  }.otherwise {
    result := Cat(io.x < 0.S, finalExp, finalSignificand)
  }

  io.y := result
}