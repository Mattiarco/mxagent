import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Helper function to convert E8M0 to FP32
  private def e8m0ToFP32(x: UInt): UInt = {
    when (x === 0xFF.U) {
      // NaN case
      0x7FC00000.U
    }.elsewhen (x === 0.U) {
      // Subnormal case: 2^-127
      0x00400000.U
    }.otherwise {
      // Normal number case: 2^(x-127)
      val exponent = (x.asSInt - 127.S).asUInt // Convert to SInt, subtract, then to UInt
      val signBit = 0.U(1.W) // Always positive
      val exponentBits = (exponent + 127.U).asUInt(8.W) // Correct width specification
      Cat(signBit, exponentBits, 0.U(23.W))
    }
  }

  // Convert the input E8M0 code to FP32
  io.y := e8m0ToFP32(io.x)
}