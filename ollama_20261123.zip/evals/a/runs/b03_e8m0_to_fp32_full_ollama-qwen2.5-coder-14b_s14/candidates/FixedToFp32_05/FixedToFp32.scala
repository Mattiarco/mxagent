import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val expBias = 127
  val expMax = 255
  val subnormalExp = 0
  val infExp = expMax
  val nanPattern = "b11111111000000000000000000000000".U(32.W)

  // Extract sign
  val sign = io.x(13)

  // Calculate the exponent
  val expAddition = (io.exp - fracBits).asSInt
  val expResult = expAddition + expBias

  // Calculate the absolute value of the significand
  val absX = io.x.abs

  // Shift the significand to align with the binary point
  val significandShift = absX << (32 - fracBits)

  // Handle special cases
  val isZero = io.x === 0.S
  val isInf = expResult >= expMax
  val isSubnormal = expResult < subnormalExp

  // Handle NaN
  val isNan = io.nan

  // Generate the significand for normal and subnormal numbers
  val significandNormal = significandShift >> (expAddition + expBias - subnormalExp)
  val significandSubnormal = significandShift >> (expResult - subnormalExp)

  // Select the correct significand based on the exponent
  val significand = Mux(isSubnormal, significandSubnormal, significandNormal)

  // Round the significand to 23 bits using RNE (Round to Nearest Even)
  val roundedSignificand = significand(23, 0)

  // Generate the exponent field
  val expField = Mux(isInf, infExp.U, expResult).asUInt(8.W)

  // Assemble the final result
  io.y := Cat(
    isNan -> nanPattern,
    isInf -> (sign << 31.U) | (infExp.U << 23.U),
    isZero -> 0.U(32.W),
    !isInf & !isNan & !isZero -> (sign << 31.U) | (expField << 23.U) | roundedSignificand
  )
}