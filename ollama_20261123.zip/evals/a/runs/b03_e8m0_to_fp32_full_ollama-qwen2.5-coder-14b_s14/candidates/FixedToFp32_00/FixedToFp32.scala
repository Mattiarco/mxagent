import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Parameters
  val w = 14
  val frac = 2

  // Calculate the effective exponent
  val effectiveExp = exp - frac

  // Calculate the absolute value of the fixed-point number
  val absX = x.abs

  // Determine the sign bit
  val signBit = x < 0.S

  // Normalize the fixed-point number to the form 1.xxxxxx * 2^exp
  val (normalizedValue, normalizedExp) = normalize(absX, effectiveExp)

  // Handle NaN case
  when (io.nan) {
    io.y := "b01111111100000000000000000000000".U
  } .otherwise {
    // Handle zero case
    when (normalizedValue === 0.U) {
      io.y := 0.U
    } .otherwise {
      // Handle overflow case
      when (normalizedExp >= 128.S) {
        io.y := Cat(signBit, "b11111111".U, 0.U(23.W))
      } .otherwise {
        // Handle subnormal case
        when (normalizedExp < -126.S) {
          val subnormalExp = normalizedExp + 126.S
          val subnormalMantissa = normalizedValue >> (-subnormalExp)
          io.y := Cat(signBit, 0.U(8.W), subnormalMantissa(22.W, 0))
        } .otherwise {
          // Handle normal case
          val biasedExp = normalizedExp + 127.S
          val mantissa = normalizedValue >> 23
          io.y := Cat(signBit, biasedExp, mantissa)
        }
      }
    }
  }

  // Function to normalize the fixed-point number
  private def normalize(value: SInt, exp: SInt): (UInt, SInt) = {
    val shiftAmount = Log2(value) - 23.S
    val normalizedValue = value >> shiftAmount
    val normalizedExp = exp + shiftAmount
    (normalizedValue.asUInt, normalizedExp)
  }
}