import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val expBias = 127
  val maxExp = expBias + 23
  val minExp = expBias - 149
  val nanPattern = "b11111111100000000000000000000000".U

  // Calculate the unbiased exponent
  val unbiasedExp = exp - fracBits.S

  // Calculate the absolute value of the fixed-point number
  val absX = io.x.abs

  // Determine the sign bit
  val signBit = io.x < 0.S

  // Determine the overflow condition
  val overflow = unbiasedExp > maxExp.S

  // Determine the underflow condition
  val underflow = unbiasedExp < minExp.S

  // Handle the overflow case
  val overflowResult = Mux(signBit, "b11111111100000000000000000000000".U, "b01111111100000000000000000000000".U)

  // Handle the underflow case
  val underflowResult = {
    val shiftAmount = (minExp.S - unbiasedExp).asUInt - 1.U
    val shiftedX = (absX << shiftAmount)(23, 0).asUInt
    Cat(signBit, "b0".U(8.W), shiftedX)
  }

  // Handle the normal case
  val normalResult = {
    val biasedExp = (unbiasedExp + expBias.S).asUInt
    val mantissa = (absX >> fracBits.U)(22, 0).asUInt
    Cat(signBit, biasedExp, mantissa)
  }

  // Handle NaN
  val nanResult = nanPattern

  // Determine the final result
  io.y := Mux(io.nan, nanResult,
           Mux(overflow, overflowResult,
               Mux(underflow, underflowResult, normalResult)))
}