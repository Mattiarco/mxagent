import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  val fracBits = 2
  val exponentBits = 8
  val mantissaBits = 23
  val maxExponent = 127 + exponentBits - 1 // 254
  val minExponent = 127 - exponentBits + 1 // 103
  val subnormalExponent = 0

  // Calculate the effective exponent
  val effectiveExp = exp - fracBits

  // Calculate the absolute value of x
  val absX = x.abs

  // Determine the sign bit
  val signBit = x < 0.S

  // Normalize the absolute value of x to find the leading one position
  val leadingOnePos = PriorityEncoder(Reverse(absX.asBools))

  // Calculate the exponent and mantissa
  val normalizedExp = effectiveExp + leadingOnePos.asSInt
  val mantissa = (absX >> (leadingOnePos - (mantissaBits + 1).asUInt)).asUInt(mantissaBits.W)

  // Determine if the result is a subnormal
  val isSubnormal = normalizedExp < minExponent.S

  // Handle the case where the result is zero
  val isZero = absX === 0.S

  // Handle the case where the result is infinity
  val isInfinity = normalizedExp > maxExponent.S

  // Handle the case where the result is a canonical NaN
  val isNaN = io.nan

  // Determine the final exponent
  val finalExp = Mux(isZero || isSubnormal, subnormalExponent.U, Mux(isInfinity, maxExponent.U, normalizedExp - 127.S))

  // Handle rounding
  val stickyBit = (absX & ((1.U << (leadingOnePos - mantissaBits - 1).asUInt) - 1.U)).orR
  val roundBit = (absX >> (leadingOnePos - mantissaBits - 1).asUInt) & 1.U
  val guardBit = (absX >> (leadingOnePos - mantissaBits - 2).asUInt) & 1.U
  val roundingUp = (guardBit & (roundBit | stickyBit)) | (guardBit & guardBit & (roundBit | stickyBit))

  // Handle sticky bit for subnormals
  val subnormalMantissa = (absX << (exponentBits - leadingOnePos - 1).asUInt).asUInt(mantissaBits.W)

  // Determine the final mantissa
  val finalMantissa = Mux(isSubnormal, subnormalMantissa, Mux(roundingUp, mantissa + 1.U, mantissa))

  // Construct the final result
  val result = Cat(
    signBit,
    finalExp,
    finalMantissa
  )

  // Handle special cases
  io.y := Mux(
    isNaN,
    "b11111111000000000000000000000000".U, // Canonical NaN
    Mux(
      isInfinity,
      Cat(signBit, "b11111111".U, "b0".U(23.W)), // Infinity
      Mux(
        isZero,
        "b0".U(32.W), // Zero
        result
      )
    )
  )
}