import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Constants
  val NaN = "b11111111100000000000000000000000".U(32.W)
  val Subnormal = "b00000000100000000000000000000000".U(32.W)
  val Bias = 127

  // Handle NaN case
  when(io.x === "b11111111".U) {
    io.y := NaN
  } .otherwise {
    // Calculate the exponent
    val exponent = io.x - Bias.U

    // Handle subnormal case (exponent < -126)
    when(exponent < -126.S) {
      io.y := Subnormal
    } .otherwise {
      // Calculate the IEEE-754 binary32 representation
      val sign = 0.U(1.W) // Always positive
      val expBits = (exponent + Bias.U).asUInt(8.W)
      val mantissa = 0.U(23.W) // Zero mantissa for powers of 2

      io.y := Cat(sign, expBits, mantissa)
    }
  }
}