import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val frac = 2
  val bias = 127
  val maxExp = 128
  val minExp = -126
  val maxExponent = 255
  val expWidth = 8
  val mantissaWidth = 23
  val signBit = 31
  val exponentBits = 30.U
  val mantissaBits = 22.U

  // Calculate the effective exponent
  val effectiveExp = exp - frac.U

  // Determine the sign bit
  val sign = io.x < 0.S

  // Calculate the absolute value of x
  val absX = io.x.abs

  // Calculate the mantissa and exponent for the result
  val (shiftedMantissa, finalExp) = {
    val (mantissa, exponent) = if (effectiveExp >= minExp) {
      val shiftAmount = (effectiveExp - minExp).asUInt
      val shifted = (absX << shiftAmount)(mantissaWidth + 1, 1)
      val roundedMantissa = (shifted + 1.U) >> 1.U
      (roundedMantissa, effectiveExp + bias.U)
    } else {
      val shiftAmount = (minExp - effectiveExp).asUInt
      val shifted = (absX >> shiftAmount)(mantissaWidth + 1, 1)
      val roundedMantissa = (shifted + 1.U) >> 1.U
      (roundedMantissa, minExp.U)
    }
    (shiftedMantissa, finalExp)
  }

  // Handle special cases
  val result = Mux(io.nan, "b11111111100000000000000000000000".U, {
    val isZero = absX === 0.S
    val isInf = finalExp >= maxExp.U
    val isSubnormal = finalExp === 0.U
    Mux(isZero, 0.U,
      Mux(isInf, Cat(sign, "b11111111".U, "b00000000000000000000000".U),
        Mux(isSubnormal, Cat(sign, 0.U, shiftedMantissa),
          Cat(sign, finalExp, shiftedMantissa)))))
  })

  io.y := result
}