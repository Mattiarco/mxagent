import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Helper function to convert E8M0 to IEEE-754 FP32
  private def e8m0ToFP32(e8m0: UInt): UInt = {
    when (e8m0 === 0xFF.U) {
      "b01111111100000000000000000000000".U
    } .elsewhen (e8m0 === 0.U) {
      "b00000000000000000000000000000000".U
    } .otherwise {
      val exp = e8m0 - 127.U
      val signBit = 0.U(1.W) // Always 0 for positive numbers
      val exponentBits = (exp + 127.U).asUInt(8.W)
      val mantissaBits = 0.U(23.W) // Always 0 for powers of 2

      Cat(signBit, exponentBits, mantissaBits)
    }
  }

  // Convert the input E8M0 code to IEEE-754 FP32
  io.y := e8m0ToFP32(io.x)
}