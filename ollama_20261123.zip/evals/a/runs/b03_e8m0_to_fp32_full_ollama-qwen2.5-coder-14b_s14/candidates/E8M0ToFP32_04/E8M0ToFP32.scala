import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Constants
  val NaN = "b11111111100000000000000000000000".U(32.W)
  val Subnormal = "b00000000100000000000000000000000".U(32.W)
  val Bias = 127

  // Determine if the input is NaN
  val isNaN = io.x === 0xFF.U

  // Calculate the exponent for the output
  val exponent = io.x - Bias.U

  // Handle special cases
  when (isNaN) {
    io.y := NaN
  } .elsewhen (exponent === -127.S) {
    io.y := Subnormal
  } .otherwise {
    // Normal number: bias the exponent and set the sign bit to zero
    val biasedExponent = exponent + Bias.U
    io.y := Cat(0.U(1.W), biasedExponent, 0.U(23.W))
  }
}