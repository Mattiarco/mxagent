package cand_E8M0ToFP32_08

import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Define the output bits for the IEEE-754 binary32 format
  val signBit = io.x(7)
  val exponentBits = io.x - 127.U
  val exponentValue = exponentBits & 0xFF.U
  val exponentZero = exponentBits === 0.U
  val exponentMax = exponentBits === 127.U

  // Handle NaN case
  val isNaN = io.x === 0xFF.U
  val nanResult = "b01111111100000000000000000000000".U

  // Handle zero case
  val isZero = io.x === 0.U
  val zeroResult = "b00000000000000000000000000000000".U

  // Handle subnormal case
  val isSubnormal = exponentZero
  val subnormalResult = "b00000000000000000000000000000000".U

  // Handle normal case
  val normalExponent = Mux(exponentBits < 0.U, 0.U, Mux(exponentBits > 254.U, 255.U, exponentBits))
  val normalResult = Cat(signBit, normalExponent, Fill(23, 0.U))

  // Select the correct result based on the input conditions
  io.y := Mux(isNaN, nanResult,
           Mux(isZero, zeroResult,
           Mux(isSubnormal, subnormalResult,
               normalResult)))
}