package cand_it00

import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Extract sign, exponent, and mantissa from the input
  val sign = io.a(3)
  val exponent = io.a(2, 1)
  val mantissa = io.a(0)

  // Decode the E2M1 code into a signed integer
  val decodedValue = Mux(exponent === 0.U && mantissa === 0.U, 0.S, // Zero codes
    Mux(exponent === 0.U, (mantissa << 1).asSInt, // Exponent 0: 0.5, 1.5
      Mux(exponent === 1.U, (mantissa << 2).asSInt, // Exponent 1: 1.0, 3.0
        (mantissa << 3).asSInt // Exponent 2: 2.0, 6.0
      )
    )
  )

  // Apply the sign to the decoded value
  io.y := Mux(sign === 0.U, decodedValue, -decodedValue)
}