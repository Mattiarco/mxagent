import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Constants
  val NaN = "b11111111000000000000000000000000".U
  val Inf = "b01111111100000000000000000000000".U
  val NegInf = "b11111111100000000000000000000000".U
  val Zero = "b00000000000000000000000000000000".U
  val NegZero = "b10000000000000000000000000000000".U

  // Check for NaN inputs
  val a_isNaN = io.a_scale === "b11111111".U
  val b_isNaN = io.b_scale === "b11111111".U
  when (a_isNaN || b_isNaN) {
    io.y := NaN
  } .otherwise {
    // Decode FP4 elements
    val a_elements = Seq.fill(32) { i => io.a((4 * i + 3, 4 * i)) }
    val b_elements = Seq.fill(32) { i => io.b((4 * i + 3, 4 * i)) }

    // Compute the dot product
    val dot_product = a_elements.zip(b_elements).map { case (a, b) =>
      val a_value = Cat(a, "b00".U) // Convert FP4 to FP16
      val b_value = Cat(b, "b00".U) // Convert FP4 to FP16
      a_value.asSInt * b_value.asSInt
    }.reduce(_ + _)

    // Scale the dot product
    val scale_factor = (io.a_scale - 127.U) + (io.b_scale - 127.U)
    val scaled_product = dot_product << scale_factor

    // Convert to IEEE-754 binary32
    val result = scaled_product.asFixedPoint(14.W, 2.B).asIEEE754Float32

    // Handle overflow
    when (scaled_product > "b01111111111111111111111111111111".S) {
      io.y := Inf
    } .elsewhen (scaled_product < "b10000000000000000000000000000000".S) {
      io.y := NegInf
    } .otherwise {
      io.y := result
    }
  }
}