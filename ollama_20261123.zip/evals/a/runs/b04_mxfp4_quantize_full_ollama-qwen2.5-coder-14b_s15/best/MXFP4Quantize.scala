import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed (element i at bits [32*i+31:32*i]). 32 binary32 values
    val scale = Output(UInt(8.W))    // E8M0 scale code. shared scale X
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). quantized elements
  })

  // Helper function to extract the sign, exponent, and mantissa from a binary32 value
  def decodeBinary32(value: UInt): (Bool, UInt, UInt) = {
    val sign = value(31)
    val exponent = value(30, 23)
    val mantissa = value(22, 0)
    (sign, exponent, mantissa)
  }

  // Helper function to check if a binary32 value is NaN or Inf
  def isSpecial(value: UInt): Bool = {
    val exponent = value(30, 23)
    exponent === "b11111111".U && value(22, 0) =/= 0.U
  }

  // Helper function to check if a binary32 value is zero
  def isZero(value: UInt): Bool = {
    value === 0.U
  }

  // Helper function to compute the E2M1 encoding of a value
  def encodeE2M1(value: SInt): UInt = {
    when(value === 0.S) {
      "b1000".U
    }.otherwise {
      val absValue = value.abs
      val exponent = log2Ceil(absValue.asUInt)
      val mantissa = (absValue.asUInt >> (exponent - 1)).asUInt(2.W)
      Cat(value < 0.S, exponent - 1, mantissa)
    }
  }

  // Extract the 32 binary32 values from the input vector
  val values = VecInit.tabulate(32)(i => io.x(32 * i + 31, 32 * i))

  // Check for NaN or Inf in the input values
  val hasSpecial = VecInit(values.map(isSpecial)).reduceTree(_ || _)

  // Check if all inputs are zero
  val allZero = VecInit(values.map(isZero)).reduceTree(_ && _)

  // Compute the maximum absolute value among the nonzero finite inputs
  val nonzeroValues = VecInit.tabulate(32) { i =>
    when(isSpecial(values(i)) || isZero(values(i))) {
      0.S
    }.otherwise {
      val sign = values(i)(31)
      val exponent = values(i)(30, 23)
      val mantissa = values(i)(22, 0)
      val absValue = Mux(exponent === 0.U, Cat("b1".U, mantissa), Cat("b1".U, exponent - "b11111111".U, mantissa))
      Mux(sign === 0.U, absValue.asSInt, -absValue.asSInt)
    }
  }
  val maxValue = nonzeroValues.reduceTree(_ max _)

  // Compute the shared exponent
  val sharedExp = Mux(hasSpecial, -127, log2Ceil(maxValue.abs.asUInt) - 2)
  val clampedSharedExp = sharedExp.max(-127).min(127)
  val scale = (clampedSharedExp + 127).asUInt(8.W)

  // Quantize each input value
  val quantizedValues = VecInit.tabulate(32) { i =>
    when(hasSpecial || allZero) {
      0.U(4.W)
    }.otherwise {
      val value = values(i).asSInt
      val scaledValue = value >> clampedSharedExp
      encodeE2M1(scaledValue)
    }
  }

  // Pack the quantized values into the output vector
  io.q := VecInit.tabulate(32)(i => quantizedValues(i)).asUInt
  io.scale := scale
}