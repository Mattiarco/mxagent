import chisel3._
import chisel3.util._

class MaxTree extends RawModule {
  val io = FlatIO(new Bundle {
    val e     = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed
    val valid = Input(UInt(32.W))   // unsigned integer
    val m     = Output(SInt(9.W))   // two's complement signed integer
    val any   = Output(Bool())      // 1-bit flag
  })

  // Helper function to extract an element from the vector
  private def getElement(vector: UInt, index: Int, width: Int): SInt = {
    val elementBits = vector(index * width + width - 1, index * width).asSInt
    elementBits
  }

  // Extract elements and valid bits
  val elements = VecInit.tabulate(32) { i => getElement(io.e, i, 9) }
  val validBits = io.valid.asBools

  // Initialize max and any flag
  val (max, any) = WireDefault((SInt(9.W).fromInt(0), false.B))

  // Iterate over elements to find the maximum
  for (i <- 0 until 32) {
    when (validBits(i)) {
      val element = elements(i)
      max := Mux(element > max, element, max)
      any := true.B
    }
  }

  // Assign outputs
  io.m := max
  io.any := any
}