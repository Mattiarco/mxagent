import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed
    val scale = Output(UInt(8.W))    // E8M0 scale code
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed
  })

  // Helper function to extract a 32-bit element from the input vector
  private def getElement(input: UInt, index: Int): UInt = {
    (input >> (32 * index)).asUInt(32.W)
  }

  // Helper function to check if a 32-bit value is NaN or Inf
  private def isNaNOrInf(value: UInt): Bool = {
    (value(31) && value(30, 23) === "b11111111".U) || (value(30, 23) === "b11111111".U)
  }

  // Helper function to compute the absolute value of a 32-bit signed integer
  private def abs(value: SInt): SInt = {
    Mux(value < 0.S, -value, value)
  }

  // Helper function to compute the floor(log2) of a 32-bit unsigned integer
  private def floorLog2(value: UInt): SInt = {
    val log2Value = Log2(value)
    Mux(value === 0.U, -1.S, log2Value)
  }

  // Extract elements and check for NaN/Inf
  val elements = VecInit((0 until 32).map(i => getElement(io.x, i)))
  val isNaNOrInfAny = elements.reduceTree((a, b) => a || isNaNOrInf(b))

  // Compute the absolute values of the elements
  val absElements = elements.map(x => abs(x.asSInt))

  // Compute the maximum absolute value
  val maxAbsValue = absElements.reduceTree((a, b) => Mux(a > b, a, b))

  // Compute the shared exponent
  val sharedExp = floorLog2(maxAbsValue) - 2.S
  val clampedSharedExp = Mux(sharedExp > 127.S, 127.S, Mux(sharedExp < -127.S, -127.S, sharedExp))
  val scale = (clampedSharedExp + 127.S).asUInt(8.W)

  // Handle NaN/Inf case
  when(isNaNOrInfAny) {
    io.scale := "b11111111".U
    io.q := 0.U(128.W)
  } .otherwise {
    // Quantize each element
    val quantizedElements = elements.map { x =>
      val sign = x(31)
      val exponent = x(30, 23)
      val mantissa = x(22, 0)

      // Compute the value in units of 1/4
      val value = Mux(exponent === 0.U,
        Mux(mantissa === 0.U, 0.S, (mantissa << 1).asSInt + 1.S), // Subnormal
        (mantissa << 1).asSInt + 3.S // Normal
      ) << (exponent - 127.U + clampedSharedExp).asSInt

      // Saturate to [-12, 12]
      val saturatedValue = Mux(value > 12.S, 12.S, Mux(value < -12.S, -12.S, value))

      // Round to nearest with ties to even
      val roundedValue = Mux(saturatedValue % 2.S === 1.S, saturatedValue + 1.S, saturatedValue)

      // Convert to E2M1 format
      val e2m1Sign = sign
      val e2m1Exponent = Mux(roundedValue === 0.S, 0.U, (roundedValue.abs >> 1).asUInt(2.W) + 1.U)
      val e2m1Mantissa = Mux(roundedValue === 0.S, 0.U, (roundedValue.abs & 1.U) << 0)
      Cat(e2m1Sign, e2m1Exponent, e2m1Mantissa)
    }

    // Pack the quantized elements into the output vector
    io.q := VecInit(quantizedElements).asUInt(128.W)
  }
}