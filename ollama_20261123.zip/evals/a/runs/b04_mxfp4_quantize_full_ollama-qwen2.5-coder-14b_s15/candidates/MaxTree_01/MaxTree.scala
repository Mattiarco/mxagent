import chisel3._
import chisel3.util._

class MaxTree extends RawModule {
  val io = FlatIO(new Bundle {
    val e     = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed
    val valid = Input(UInt(32.W))   // unsigned integer
    val m     = Output(SInt(9.W))   // two's complement signed integer
    val any   = Output(Bool())      // 1-bit flag
  })

  // Helper function to extract a single element from the packed vector
  private def getElement(e: UInt, index: Int, width: Int): SInt = {
    val bitRange = (index * width + width - 1, index * width)
    e(bitRange).asSInt
  }

  // Unpack the vector of 32 x 9-bit elements
  val elements = VecInit(Seq.tabulate(32)(i => getElement(io.e, i, 9)))

  // Initialize the maximum value and the any flag
  val maxReg = RegInit(SInt(9.W), 0.S)
  val anyReg = RegInit(Bool(), false.B)

  // Iterate over the elements and update the maximum and any flag
  for (i <- 0 until 32) {
    when (io.valid(i) === 1.U) {
      when (elements(i) > maxReg) {
        maxReg := elements(i)
      }
      anyReg := true.B
    }
  }

  // Assign the outputs
  io.m := maxReg
  io.any := anyReg
}