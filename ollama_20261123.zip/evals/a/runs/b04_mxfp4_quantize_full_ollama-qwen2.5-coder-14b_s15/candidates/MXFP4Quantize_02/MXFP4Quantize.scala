import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed (element i at bits [32*i+31:32*i]). 32 binary32 values
    val scale = Output(UInt(8.W))    // E8M0 scale code. shared scale X
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). quantized elements
  })

  // Helper function to extract a 32-bit element from the input vector
  private def extractElement(input: UInt, index: Int): UInt = {
    input(32 * index + 31, 32 * index)
  }

  // Helper function to check if a float is NaN or Inf
  private def isSpecial(x: UInt): Bool = {
    (x(31, 23) === "b11111111".U) && (x(22, 0) =/= 0.U)
  }

  // Helper function to compute the absolute value of a 32-bit float
  private def abs(x: UInt): UInt = {
    (x(31) ^ 1.U) ## x(30, 0)
  }

  // Helper function to compute the floor(log2) of a 32-bit float
  private def floorLog2(x: UInt): SInt = {
    val sign = x(31)
    val exponent = x(30, 23).asSInt
    val mantissa = x(22, 0).asSInt

    val log2Mantissa = PriorityEncoder(Reverse(mantissa))
    val log2Value = exponent - 127.S + log2Mantissa
    Mux(sign === 1.U, -log2Value, log2Value)
  }

  // Helper function to extract the sign of a 32-bit float
  private def sign(x: UInt): UInt = {
    x(31)
  }

  // Helper function to extract the exponent of a 32-bit float
  private def exponent(x: UInt): UInt = {
    x(30, 23)
  }

  // Helper function to extract the mantissa of a 32-bit float
  private def mantissa(x: UInt): UInt = {
    x(22, 0)
  }

  // Helper function to convert a 32-bit float to E2M1 format
  private def toE2M1(x: UInt): UInt = {
    val sign = sign(x)
    val exponent = exponent(x)
    val mantissa = mantissa(x)

    val isZero = exponent === 0.U && mantissa === 0.U
    val isSubnormal = exponent === 0.U && mantissa =/= 0.U

    val e = Mux(isZero || isSubnormal, 0.U, exponent - 127.U)
    val m = Mux(isSubnormal, mantissa << 1, mantissa ## 1.U(1.W))

    val e2m1E = e(1, 0)
    val e2m1M = (m >> 21) & 1.U

    sign ## e2m1E ## e2m1M
  }

  // Helper function to clamp a value to a range
  private def clamp(value: SInt, min: SInt, max: SInt): SInt = {
    Mux(value < min, min, Mux(value > max, max, value))
  }

  // Helper function to round to nearest with ties to even
  private def roundToNearest(value: SInt, roundBits: Int): SInt = {
    val roundMask = (1 << roundBits) - 1
    val rounded = (value >> roundBits) << roundBits
    val remainder = value & roundMask
    val halfway = (1 << (roundBits - 1)).U.asSInt

    Mux(remainder < halfway, rounded,
      Mux(remainder > halfway, rounded + (1 << roundBits).S,
        Mux((value >> (roundBits + 1)) & 1.U === 1.U, rounded + (1 << roundBits).S, rounded)))
  }

  // Process each element
  val elements = VecInit((0 until 32).map(i => extractElement(io.x, i)))

  // Check for special values (NaN or Inf)
  val hasSpecial = elements.reduceTree((a, b) => a || isSpecial(b))

  // Compute the absolute values of the elements
  val absElements = elements.map(abs)

  // Compute the floor(log2) of the absolute values
  val log2AbsElements = absElements.map(floorLog2)

  // Compute the shared exponent
  val maxLog2Abs = log2AbsElements.reduceTree((a, b) => Mux(a > b, a, b))
  val sharedExp = clamp(maxLog2Abs - 2.S, -127.S, 127.S)
  val scale = (sharedExp + 127.S).asUInt

  // Handle the case where all inputs are zero
  val allZero = elements.reduceTree((a, b) => a && b === 0.U)

  // Quantize each element
  val quantizedElements = elements.map { x =>
    val sign = sign(x)
    val exponent = exponent(x)
    val mantissa = mantissa(x)

    val isZero = exponent === 0.U && mantissa === 0.U
    val isSubnormal = exponent === 0.U && mantissa =/= 0.U

    val e = Mux(isZero || isSubnormal, 0.U, exponent - 127.U)
    val m = Mux(isSubnormal, mantissa << 1, mantissa ## 1.U(1.W))

    val value = (e - sharedExp) * 2.S + m.asSInt
    val roundedValue = roundToNearest(value, 1)
    val saturatedValue = clamp(roundedValue, -12.S, 12.S)
    val e2m1 = (saturatedValue >> 1) & 3.U
    val m2m1 = saturatedValue & 1.U

    sign ## e2m1 ## m2m1
  }

  // Assign outputs
  io.scale := Mux(hasSpecial, 0xFF.U, scale)
  io.q := VecInit(quantizedElements).asUInt
}