import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed
    val scale = Output(UInt(8.W))    // E8M0 scale code. shared scale X
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed
  })

  // Helper function to extract a 32-bit float from a packed vector
  private def extractFloat(x: UInt, i: Int): UInt = {
    (x >> (32 * i)).asUInt(32.W)
  }

  // Helper function to determine if a float is NaN or Inf
  private def isNaNOrInf(x: UInt): Bool = {
    (x(30, 23) === 0xFF.U) && (x(22, 0) =/= 0.U)
  }

  // Helper function to determine if a float is zero
  private def isZero(x: UInt): Bool = {
    (x === 0.U)
  }

  // Helper function to extract the sign bit of a float
  private def getSign(x: UInt): UInt = {
    x(31).asUInt(1.W)
  }

  // Helper function to extract the exponent of a float
  private def getExponent(x: UInt): UInt = {
    x(30, 23)
  }

  // Helper function to extract the mantissa of a float
  private def getMantissa(x: UInt): UInt = {
    x(22, 0)
  }

  // Helper function to compute the absolute value of a float
  private def absFloat(x: UInt): UInt = {
    x(30, 0)
  }

  // Helper function to compute the floor(log2) of a float
  private def floorLog2(x: UInt): UInt = {
    PriorityEncoder(Reverse(absFloat(x) >> 1.U))
  }

  // Helper function to convert a float to an SInt representation
  private def floatToSInt(x: UInt): SInt = {
    val sign = getSign(x).asSInt
    val exponent = getExponent(x).asSInt
    val mantissa = getMantissa(x).asSInt
    val shift = exponent - 127.S - 23.S
    val value = (sign * (mantissa + 0x800000.U)).asSInt << shift
    value
  }

  // Helper function to convert an SInt to an FP4 E2M1 representation
  private def sIntToFP4(x: SInt): UInt = {
    val sign = x < 0.S
    val absValue = x.abs
    val scaledValue = (absValue + 0x200.S) >> 9.S // Scale to [-12, 12]
    val roundedValue = Mux(scaledValue > 0x7.S, 0x7.U, Mux(scaledValue < -0x7.S, 0x8.U, scaledValue.asUInt(4.W)))
    Cat(sign.asUInt, roundedValue)
  }

  // Extract all 32 input floats
  val inputs = VecInit.tabulate(32)(i => extractFloat(io.x, i))

  // Determine if any input is NaN or Inf
  val anyNaNOrInf = inputs.map(isNaNOrInf).reduceTree(_ || _)

  // Determine if all inputs are zero
  val allZero = inputs.map(isZero).reduceTree(_ && _)

  // Compute the maximum absolute value of nonzero finite inputs
  val maxAbsValue = inputs.map(absFloat).reduceTree((a, b) => Mux(a > b, a, b))

  // Compute the shared exponent
  val sharedExponent = Mux(allZero, -127.S, Mux(anyNaNOrInf, 127.S, floorLog2(maxAbsValue) - 2.S))

  // Clamp the shared exponent to [-127, 127]
  val clampedSharedExponent = Mux(sharedExponent > 127.S, 127.S, Mux(sharedExponent < -127.S, -127.S, sharedExponent))

  // Compute the scale code
  val scaleCode = (clampedSharedExponent + 127.S).asUInt(8.W)

  // Quantize each input to FP4 E2M1
  val quantizedValues = inputs.map { x =>
    if (anyNaNOrInf || allZero) {
      0.U(4.W)
    } else {
      val floatValue = floatToSInt(x)
      val scaledValue = floatValue >> clampedSharedExponent
      sIntToFP4(scaledValue)
    }
  }

  // Combine the quantized values into a single 128-bit output
  val q = VecInit(quantizedValues).asUInt(128.W)

  // Assign outputs
  io.scale := scaleCode
  io.q := q
}