import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed
    val scale = Output(UInt(8.W))    // E8M0 scale code
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed
  })

  // Helper function to extract a 32-bit element from the input vector
  private def extractElement(input: UInt, index: Int): UInt = {
    input(index * 32 + 31, index * 32)
  }

  // Helper function to determine if a 32-bit value is NaN or Inf
  private def isNaNOrInf(value: UInt): Bool = {
    (value(31) && value(30, 23) === "b11111111".U) || (value(30, 23) === "b11111111".U && value(22, 0) =/= 0.U)
  }

  // Helper function to determine if a 32-bit value is zero
  private def isZero(value: UInt): Bool = {
    value === 0.U
  }

  // Helper function to determine if a 32-bit value is subnormal
  private def isSubnormal(value: UInt): Bool = {
    value(30, 23) === 0.U && value(22, 0) =/= 0.U
  }

  // Helper function to calculate the absolute value of a 32-bit float
  private def abs(value: UInt): UInt = {
    value(30, 0)
  }

  // Helper function to calculate the floor(log2) of a 32-bit float
  private def floorLog2(value: UInt): SInt = {
    val exp = value(30, 23)
    val mant = value(22, 0)
    val subnormalExp = Mux(isSubnormal(value), Log2(mant), exp.asSInt - 127.S)
    Mux(isZero(value), -127.S, subnormalExp)
  }

  // Helper function to calculate the E2M1 encoding of a 32-bit float
  private def e2m1Encode(value: UInt, scale: SInt): UInt = {
    val sign = value(31)
    val absValue = abs(value)
    val scaledValue = absValue >> (scale + 2.S)
    val mantissa = scaledValue(1, 0)
    val exponent = Mux(scaledValue(2), 1.U, 0.U)
    Cat(sign, exponent, mantissa)
  }

  // Helper function to calculate the shared exponent
  private def calculateSharedExponent(inputs: Seq[UInt]): SInt = {
    val nonzeroInputs = inputs.filterNot(isZero)
    val nonzeroExponents = nonzeroInputs.map(floorLog2)
    val maxExponent = nonzeroExponents.reduceTree(_ max _)
    Mux(nonzeroInputs.isEmpty, -127.S, maxExponent - 2.S)
  }

  // Helper function to calculate the scale code
  private def calculateScale(sharedExponent: SInt): UInt = {
    val clampedExponent = Mux(sharedExponent > 127.S, 127.S, Mux(sharedExponent < -127.S, -127.S, sharedExponent))
    (clampedExponent + 127.S).asUInt
  }

  // Helper function to calculate the quantized value
  private def quantizeElement(value: UInt, scale: SInt): UInt = {
    val e2m1 = e2m1Encode(value, scale)
    val sign = e2m1(3)
    val exponent = e2m1(2, 1)
    val mantissa = e2m1(0)
    val decodedValue = Mux(exponent === 0.U, 0.5.U, 2.0.U) * (1.0.U + mantissa.asUInt(1.W) * 0.5.U)
    val scaledValue = decodedValue * (2.0.U ** (scale + 2.S))
    val roundedValue = Round(scaledValue, 1.B)
    val saturatedValue = Mux(roundedValue > 6.0.U, 6.0.U, Mux(roundedValue < -6.0.U, -6.0.U, roundedValue))
    e2m1Encode(saturatedValue.asUInt, 0.S)
  }

  // Main logic
  val inputs = (0 until 32).map(i => extractElement(io.x, i))
  val anyNaNOrInf = inputs.exists(isNaNOrInf)
  val allZero = inputs.forall(isZero)
  val sharedExponent = calculateSharedExponent(inputs)
  val scale = calculateScale(sharedExponent)

  io.scale := Mux(anyNaNOrInf, 0xFF.U, scale)
  io.q := VecInit(inputs.map { value =>
    Mux(anyNaNOrInf || allZero, 0.U, quantizeElement(value, sharedExponent))
  }).asUInt
}