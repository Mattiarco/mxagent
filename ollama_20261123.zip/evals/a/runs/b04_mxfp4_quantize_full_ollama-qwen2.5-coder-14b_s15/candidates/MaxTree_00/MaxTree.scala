import chisel3._
import chisel3.util._

class MaxTree extends RawModule {
  val io = FlatIO(new Bundle {
    val e     = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val valid = Input(UInt(32.W))   // unsigned integer
    val m     = Output(SInt(9.W))   // two's complement signed integer
    val any   = Output(Bool())      // 1-bit flag
  })

  // Helper function to extract an element from the packed vector
  private def extractElement(vec: UInt, index: Int, width: Int): SInt = {
    val hi = index * width + width - 1
    val lo = index * width
    vec(hi, lo).asSInt
  }

  // Extract all elements from the packed vector
  val elements = VecInit(Seq.tabulate(32)(i => extractElement(io.e, i, 9)))

  // Find the maximum element among the valid ones
  val maxElement = elements.zip(io.valid.asBools).reduceTree { case ((elem1, valid1), (elem2, valid2)) =>
    Mux(valid1 && valid2, Mux(elem1 > elem2, elem1, elem2), Mux(valid1, elem1, elem2))
  }

  // Determine if any valid bit is set
  val anyValid = io.valid.orR

  // Assign outputs
  io.m := Mux(anyValid, maxElement, 0.S(9.W))
  io.any := anyValid
}