import chisel3._
import chisel3.util._

class MaxTree extends RawModule {
  val io = FlatIO(new Bundle {
    val e     = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val valid = Input(UInt(32.W))   // unsigned integer
    val m     = Output(SInt(9.W))   // two's complement signed integer
    val any   = Output(Bool())      // 1-bit flag
  })

  // Helper function to extract the i-th element from the vector e
  private def extractElement(e: UInt, i: Int, w: Int): SInt = {
    e(i * w + w - 1, i * w).asSInt
  }

  // Number of elements
  val n = 32
  // Bit width of each element
  val w = 9

  // Convert the input vector to a vector of SInts
  val elements = VecInit(Seq.tabulate(n)(i => extractElement(io.e, i, w)))

  // Vector to store the valid bits
  val validBits = VecInit(io.valid.asBools)

  // Compute the maximum value and check if any bit in valid is set
  val (maxValue, anyValid) = elements.zip(validBits).foldLeft((SInt(w.W), false.B)) {
    case ((maxSoFar, anySoFar), (element, isValid)) =>
      val newMax = Mux(isValid && element > maxSoFar, element, maxSoFar)
      (newMax, anySoFar || isValid)
  }

  // Assign outputs
  io.m := maxValue
  io.any := anyValid
}