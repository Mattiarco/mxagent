import chisel3._
import chisel3.util._

class MaxTree extends RawModule {
  val io = FlatIO(new Bundle {
    val e     = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val valid = Input(UInt(32.W))   // unsigned integer
    val m     = Output(SInt(9.W))   // two's complement signed integer
    val any   = Output(Bool())      // 1-bit flag
  })

  private def extractElement(vector: UInt, index: Int, width: Int): SInt = {
    val hi = index * width + width - 1
    val lo = index * width
    vector(hi, lo).asSInt
  }

  private def isValidBit(valid: UInt, index: Int): Bool = {
    valid(index)
  }

  val elements = (0 until 32).map { i =>
    extractElement(io.e, i, 9)
  }

  val validBits = (0 until 32).map { i =>
    isValidBit(io.valid, i)
  }

  val maxResult = WireDefault(elements(0))
  val anyValid = WireDefault(validBits(0))

  for (i <- 1 until 32) {
    when(validBits(i)) {
      maxResult := Mux(maxResult > elements(i), maxResult, elements(i))
      anyValid := true.B
    }
  }

  io.m := maxResult
  io.any := anyValid
}