import chisel3._
import chisel3.util._

class MaxTree extends RawModule {
  val io = FlatIO(new Bundle {
    val e     = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed
    val valid = Input(UInt(32.W))   // unsigned integer
    val m     = Output(SInt(9.W))   // two's complement signed integer
    val any   = Output(Bool())      // 1-bit flag
  })

  // Unpack the input vector into a Vec of 32 SInts
  val elements = Wire(Vec(32, SInt(9.W)))
  for (i <- 0 until 32) {
    elements(i) := io.e((i + 1) * 9 - 1, i * 9).asSInt
  }

  // Function to compute the maximum of two SInts
  def max(a: SInt, b: SInt): SInt = Mux(a > b, a, b)

  // Compute the masked maximum
  val maskedMax = WireDefault(SInt(9.W).fromInt(Int.MinValue)) // Default to the smallest possible SInt value
  val anyValid = WireDefault(false.B)

  for (i <- 0 until 32) {
    when (io.valid(i) === 1.U) {
      maskedMax := max(maskedMax, elements(i))
      anyValid := true.B
    }
  }

  io.m := maskedMax
  io.any := anyValid
}