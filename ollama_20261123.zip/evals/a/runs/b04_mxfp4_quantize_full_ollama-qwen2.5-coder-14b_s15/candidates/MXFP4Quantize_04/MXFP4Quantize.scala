import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed
    val scale = Output(UInt(8.W))    // E8M0 scale code
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed
  })

  // Helper function to extract a 32-bit word from the input vector
  def extractWord(index: Int): UInt = (io.x >> (index * 32)) & 0xFFFFFFFF.U

  // Helper function to determine if a 32-bit word is NaN or Inf
  def isNaNOrInf(word: UInt): Bool = (word(31) && (word(30, 23) === 0xFF.U)) || (word(30, 23) === 0xFF.U)

  // Helper function to determine if a 32-bit word is zero
  def isZero(word: UInt): Bool = word === 0.U

  // Helper function to extract the sign of a 32-bit word
  def extractSign(word: UInt): Bool = word(31)

  // Helper function to extract the exponent of a 32-bit word
  def extractExponent(word: UInt): SInt = (word(30, 23) - 127).asSInt

  // Helper function to extract the mantissa of a 32-bit word
  def extractMantissa(word: UInt): UInt = Cat(word(22, 0), Fill(23, 0.U))

  // Helper function to calculate the absolute value of a 32-bit word
  def absValue(word: UInt): UInt = if (word(31)) ~word + 1.U else word

  // Helper function to calculate the log2 of a 32-bit word
  def log2(word: UInt): SInt = {
    val log2Value = PriorityEncoder(Reverse(word.asBools())) + 1.S
    Mux(word === 0.U, -1.S, log2Value)
  }

  // Helper function to calculate the E2M1 encoding of a 32-bit word
  def e2m1Encode(word: UInt, sharedExp: SInt): UInt = {
    val sign = extractSign(word)
    val absWord = absValue(word)
    val exponent = extractExponent(absWord)
    val mantissa = extractMantissa(absWord)
    val scaledValue = (absWord << (127.S - exponent - sharedExp)).asSInt

    // Determine the E2M1 code
    val code = MuxCase(0.U(4.W), Seq(
      (scaledValue > 12.S) -> 0b1111.U,  // -6.0
      (scaledValue > 9.S)  -> 0b1110.U,  // -4.0
      (scaledValue > 6.S)  -> 0b1101.U,  // -3.0
      (scaledValue > 4.S)  -> 0b1100.U,  // -2.0
      (scaledValue > 3.S)  -> 0b1011.U,  // -1.5
      (scaledValue > 2.S)  -> 0b1010.U,  // -1.0
      (scaledValue > 1.S)  -> 0b1001.U,  // -0.5
      (scaledValue > 0.S)  -> 0b1000.U,  // -0.0
      (scaledValue === 0.S) -> 0b1000.U,  // -0.0
      (scaledValue === -1.S) -> 0b0001.U, // +0.5
      (scaledValue === -2.S) -> 0b0010.U, // +1.0
      (scaledValue === -3.S) -> 0b0011.U, // +1.5
      (scaledValue === -4.S) -> 0b0100.U, // +2.0
      (scaledValue === -6.S) -> 0b0101.U, // +3.0
      (scaledValue === -9.S) -> 0b0110.U, // +4.0
      (scaledValue === -12.S) -> 0b0111.U // +6.0
    ))

    Cat(sign, code)
  }

  // Check if any input is NaN or Inf
  val anyNaNOrInf = (0 until 32).map(i => isNaNOrInf(extractWord(i))).reduce(_ || _)

  // Check if all inputs are zero
  val allZero = (0 until 32).map(i => isZero(extractWord(i))).reduce(_ && _)

  // Calculate the maximum absolute value of the inputs
  val maxAbsValue = (0 until 32).map(i => absValue(extractWord(i))).reduceTree(_ max _)

  // Calculate the shared exponent
  val maxAbsLog2 = log2(maxAbsValue)
  val sharedExp = Mux(allZero, -127.S, Mux(anyNaNOrInf, 127.S, maxAbsLog2 - 2.S))
  val clampedSharedExp = sharedExp.clamp(-127.S, 127.S)
  val scale = (clampedSharedExp + 127.S).asUInt

  // Quantize each element
  val q = VecInit((0 until 32).map(i => {
    val word = extractWord(i)
    e2m1Encode(word, clampedSharedExp)
  })).asUInt

  // Handle NaN and Inf cases
  io.scale := Mux(anyNaNOrInf, 0xFF.U, scale)
  io.q := Mux(anyNaNOrInf, 0.U(128.W), q)
}