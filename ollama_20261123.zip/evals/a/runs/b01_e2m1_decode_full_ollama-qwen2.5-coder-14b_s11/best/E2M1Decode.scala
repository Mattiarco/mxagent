import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Lookup table for E2M1 to SInt(5.W) conversion
  private val e2m1ToSInt: Vec[SInt] = VecInit(
    Seq(
      0.S,   // 0000 (s=0 e=00 m=0) = +0
      1.S,   // 0001 (s=0 e=00 m=1) = +0.5
      2.S,   // 0010 (s=0 e=01 m=0) = +1
      3.S,   // 0011 (s=0 e=01 m=1) = +1.5
      4.S,   // 0100 (s=0 e=10 m=0) = +2
      6.S,   // 0101 (s=0 e=10 m=1) = +3
      8.S,   // 0110 (s=0 e=11 m=0) = +4
      12.S,  // 0111 (s=0 e=11 m=1) = +6
      0.S,   // 1000 (s=1 e=00 m=0) = -0
      -1.S,  // 1001 (s=1 e=00 m=1) = -0.5
      -2.S,  // 1010 (s=1 e=01 m=0) = -1
      -3.S,  // 1011 (s=1 e=01 m=1) = -1.5
      -4.S,  // 1100 (s=1 e=10 m=0) = -2
      -6.S,  // 1101 (s=1 e=10 m=1) = -3
      -8.S,  // 1110 (s=1 e=11 m=0) = -4
      -12.S  // 1111 (s=1 e=11 m=1) = -6
    )
  )

  // Decode the E2M1 code using the lookup table
  io.y := e2m1ToSInt(io.a)
}