// generato da mxagent.synth.wrapper per E2M1Decode (b01_e2m1_decode)
module mxagent_ppa_wrap(input clk, input din, output dout);
  reg [3:0] sh;
  always @(posedge clk) sh <= {sh[2:0], din};
  wire [4:0] o_y;
  E2M1Decode dut(.a(sh[3:0]), .y(o_y));
  reg [4:0] q;
  always @(posedge clk) q <= {o_y};
  assign dout = ^q;
endmodule
