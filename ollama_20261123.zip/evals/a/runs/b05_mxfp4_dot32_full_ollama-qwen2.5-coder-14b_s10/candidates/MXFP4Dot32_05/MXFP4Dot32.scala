import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exp = value(2, 1)
    val mant = value(0)
    val isSubnormal = exp === 0.U
    val subnormalValue = Mux(sign, -1.S(4.W) * (mant.asSInt + 1.S(1.W)) >> 1, (mant.asSInt + 1.S(1.W)) >> 1)
    val normalValue = Mux(sign, -1.S(4.W) * ((1.U(2.W) + mant.asUInt) << exp), (1.U(2.W) + mant.asUInt) << exp)
    Mux(isSubnormal, subnormalValue, normalValue)
  }

  // Decode all elements in the input vectors
  val aElements = VecInit((0 until 32).map(i => decodeFP4(io.a(4*i+3, 4*i))))
  val bElements = VecInit((0 until 32).map(i => decodeFP4(io.b(4*i+3, 4*i))))

  // Compute the dot product
  val products = VecInit((0 until 32).map(i => aElements(i) * bElements(i)))
  val dotProduct = products.reduceTree(_ +& _)

  // Handle scale codes
  val isAScaleNaN = io.a_scale === 0xFF.U
  val isBScaleNaN = io.b_scale === 0xFF.U
  val isNaN = isAScaleNaN | isBScaleNaN

  // Compute the final result
  val scaleShift = (io.a_scale.asSInt - 127.S) + (io.b_scale.asSInt - 127.S)
  val scaledDotProduct = dotProduct << scaleShift

  val result = Mux(isNaN, "b11111111000000000000000000000000".U, 
                   Mux(scaledDotProduct === 0.S, 0.U, 
                       ieee754Round(scaledDotProduct)))

  io.y := result

  // Helper function to perform IEEE-754 rounding
  private def ieee754Round(value: SInt): UInt = {
    val sign = value(15)
    val absValue = value.abs
    val intPart = absValue >> 2
    val fracPart = absValue & 0b11.U

    val roundBit = fracPart(1)
    val stickyBit = fracPart.orR
    val roundUp = roundBit & (stickyBit | fracPart(0))

    val roundedValue = intPart + Mux(roundUp, 1.U, 0.U)
    val result = Cat(sign, Fill(9, roundedValue(8)), roundedValue(7, 0))

    // Handle overflow to infinity
    val isOverflow = roundedValue(8)
    val infValue = Cat(sign, "b11111111".U, Fill(23, 0.U))

    Mux(isOverflow, infValue, result)
  }
}