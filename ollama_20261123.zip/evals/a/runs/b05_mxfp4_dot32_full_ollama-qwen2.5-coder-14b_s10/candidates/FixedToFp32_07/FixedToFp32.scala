import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val expBias = 127
  val maxExp = 128
  val minExp = -126
  val infBits = "b11111111000000000000000000000000".U
  val nanBits = "b11111111100000000000000000000000".U
  val zeroBits = "b00000000000000000000000000000000".U

  // Calculate the effective exponent
  val effectiveExp = io.exp - fracBits.asSInt

  // Calculate the absolute value of the fixed-point number
  val absX = io.x.abs

  // Calculate the leading one position of the absolute value
  val leadingOnePos = PriorityEncoder(Reverse(absX.asUInt))

  // Calculate the biased exponent
  val biasedExp = effectiveExp + leadingOnePos.asSInt + expBias.asSInt

  // Calculate the mantissa
  val mantissaBits = absX.asUInt >> (leadingOnePos - (32 - fracBits - 1).asSInt)

  // Handle NaN case
  when (io.nan) {
    io.y := nanBits
  } .elsewhen (absX === 0.S) {
    io.y := zeroBits
  } .elsewhen (biasedExp >= maxExp.asSInt) {
    io.y := infBits
  } .elsewhen (biasedExp < minExp.asSInt) {
    // Handle subnormal numbers
    val subnormalExp = (minExp - 1).asSInt
    val subnormalMantissaBits = absX.asUInt >> (leadingOnePos - (32 - fracBits - 1 - subnormalExp).asSInt)
    io.y := Cat(0.U(1.W), subnormalMantissaBits(22.W, 0))
  } .otherwise {
    // Normal number
    io.y := Cat(io.x(13), biasedExp.asUInt(8.W), mantissaBits(22.W, 0))
  }
}