import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val subnormal = exponent === 0.U
    val subnormalValue = Cat(sign, 0.U(2.W), mantissa).asSInt
    val normalValue = (sign ## (exponent + 1.U) ## mantissa).asSInt
    Mux(subnormal, subnormalValue, normalValue)
  }

  // Helper function to encode FP32
  private def encodeFP32(value: SInt): UInt = {
    val absValue = value.abs
    val sign = value < 0.S
    val isZero = absValue === 0.S
    val isInf = absValue >= 0x7F800000.U.asSInt
    val isSubnormal = absValue < 0x800000.U.asSInt

    val exponent = Log2(absValue) + 127.U
    val mantissa = (absValue << (23 - exponent)).asUInt(23.W)

    val zero = 0.U(32.W)
    val inf = Cat(sign, 0xFF.U(8.W), 0.U(23.W))
    val subnormalValue = Cat(sign, 0.U(1.W), absValue << (126 - exponent)).asUInt(32.W)
    val normalValue = Cat(sign, exponent, mantissa)

    Mux(isZero, zero, Mux(isInf, inf, Mux(isSubnormal, subnormalValue, normalValue)))
  }

  // Decode the scales
  val aScale = io.a_scale
  val bScale = io.b_scale

  // Check for NaN scales
  val isNaNScale = aScale === 0xFF.U || bScale === 0xFF.U
  val resultNaN = isNaNScale ? 0x7FC00000.U : 0.U

  // Decode the FP4 elements
  val aElements = VecInit((0 until 32).map(i => decodeFP4(io.a(4 * i + 3, 4 * i))))
  val bElements = VecInit((0 until 32).map(i => decodeFP4(io.b(4 * i + 3, 4 * i))))

  // Compute the dot product
  val products = aElements.zip(bElements).map { case (a, b) => a * b }
  val dotProduct = VecInit(products).reduceTree(_ +& _)

  // Scale the dot product
  val scaleShift = (aScale - 127.U) + (bScale - 127.U)
  val scaledDotProduct = dotProduct << scaleShift

  // Round the result to FP32
  val roundedResult = encodeFP32(scaledDotProduct)

  // Final result
  io.y := Mux(isNaNScale, resultNaN, roundedResult)
}