import chisel3._
import chisel3.util._

class AdderTree extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val y = Output(SInt(14.W))  // two's complement signed integer
  })

  // Helper function to extract a signed w-bit integer from a packed vector
  private def extractSignedElement(x: UInt, index: Int, width: Int): SInt = {
    val element = x(index * width + width - 1, index * width).asSInt
    element
  }

  // Number of elements and width of each element
  val n = 32
  val w = 9

  // Extract all elements from the packed vector
  val elements = VecInit((0 until n).map(i => extractSignedElement(io.x, i, w)))

  // Reduce the vector using an adder tree
  val sum = elements.reduceTree(_ +& _)

  // Cast the result to SInt with the required width
  io.y := sum.asSInt
}