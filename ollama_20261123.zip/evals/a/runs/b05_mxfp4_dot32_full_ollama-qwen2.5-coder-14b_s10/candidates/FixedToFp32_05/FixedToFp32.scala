import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val intBits = 14
  val expBias = 127
  val subnormalBias = -149
  val expWidth = 8
  val mantissaWidth = 23

  // Convert exp from SInt to UInt and adjust for the fracBits
  val expAdjusted = (io.exp.asUInt + fracBits.U(10.W)).asSInt

  // Calculate the total exponent
  val totalExp = expAdjusted + io.x.getWidth.asSInt - 1.S(10.W) - fracBits.S(10.W)

  // Calculate the absolute value of the integer part
  val absX = io.x.asUInt

  // Determine the sign bit
  val signBit = io.x(13)

  // Normalize the value to the range [1.0, 2.0)
  val (normalizedMantissa, normalizedExp) = normalize(absX)

  // Adjust the exponent for the normalized mantissa
  val finalExp = totalExp + normalizedExp.asSInt - 1.S(10.W)

  // Round the normalized mantissa to 23 bits
  val roundedMantissa = round(normalizedMantissa, mantissaWidth + 1)

  // Handle special cases
  io.y := Mux(io.nan, "b11111111000000000000000000000000".U, // Canonical NaN
    Mux(finalExp < -expBias.S(10.W), createSubnormal(roundedMantissa, finalExp),
      Mux(finalExp > expBias.S(10.W), "b01111111100000000000000000000000".U, // Infinity
        createNormal(roundedMantissa, finalExp, signBit)
      )
    )
  )

  // Normalize the mantissa to the range [1.0, 2.0)
  private def normalize(x: UInt): (UInt, SInt) = {
    val maxMantissa = (1.U << (intBits - 1)).asUInt
    val shiftAmount = Log2(x + 1.U) - 1.U
    val normalizedMantissa = (x << shiftAmount) >> (intBits - mantissaWidth - 1).U
    (normalizedMantissa, (shiftAmount - fracBits.U(10.W)).asSInt)
  }

  // Round the mantissa to the desired width
  private def round(x: UInt, width: Int): UInt = {
    val roundBit = x(width)
    val stickyBit = x(width - 1, 0).orR
    val incr = (roundBit && stickyBit).asUInt
    (x >> 1) + incr
  }

  // Create a subnormal number
  private def createSubnormal(mantissa: UInt, exp: SInt): UInt = {
    val subnormalShift = (-exp - subnormalBias.S(10.W)).asUInt
    val subnormalMantissa = (mantissa << subnormalShift) >> (mantissaWidth + 1).U
    Cat(signBit, subnormalShift, subnormalMantissa)
  }

  // Create a normal number
  private def createNormal(mantissa: UInt, exp: SInt, sign: Bool): UInt = {
    val expField = (exp + expBias.S(10.W)).asUInt
    Cat(sign, expField, mantissa)
  }
}