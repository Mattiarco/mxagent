import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val totalBits = 14
  val bias = 127
  val subnormalBias = 0
  val infBits = 0xFF
  val nanBits = 0x7FC00000.U
  val zeroBits = 0x00000000.U

  // Helper function to calculate the sign bit
  private def signBit(value: SInt): UInt = value.asUInt(1)(0)

  // Helper function to calculate the absolute value
  private def abs(value: SInt): UInt = value.asUInt(totalBits.W) & (~(0x8000.U(totalBits.W)))

  // Calculate the shifted value
  val shiftedValue = Mux(io.exp > -fracBits.S, io.x << (io.exp - (-fracBits.S)).asUInt, io.x >> ((-fracBits.S - io.exp).asUInt))

  // Determine the exponent
  val exponent = Mux(io.exp >= -fracBits.S, io.exp - (-fracBits.S) + bias.S, subnormalBias.S)

  // Determine the mantissa
  val mantissa = shiftedValue >> fracBits

  // Handle subnormal numbers
  val subnormalExp = subnormalBias.S - (io.exp + fracBits.S)
  val subnormalMantissa = shiftedValue << (23 - subnormalExp.asUInt)
  val subnormalMantissaShifted = subnormalMantissa >> (23 - subnormalExp.asUInt + 1)
  val subnormalBits = (subnormalExp.asUInt + 127) << 23 | subnormalMantissaShifted

  // Determine if the number is subnormal
  val isSubnormal = io.exp < -fracBits.S

  // Handle overflow
  val isOverflow = io.exp > (bias.S + 24.S - fracBits.S)

  // Handle underflow to zero
  val isUnderflow = io.exp < -fracBits.S - 23.S

  // Round to nearest even
  val roundBit = shiftedValue(fracBits - 1)
  val stickyBit = shiftedValue(fracBits - 2, 0).orR
  val carry = roundBit & stickyBit
  val roundedMantissa = (mantissa + carry.asUInt) << 1

  // Handle NaN
  val isNaN = io.nan

  // Generate the final output
  io.y := Mux(isNaN, nanBits,
    Mux(isOverflow, (signBit(io.x) << 31) | (infBits << 23),
      Mux(isUnderflow, zeroBits,
        Mux(isSubnormal, subnormalBits,
          (signBit(io.x) << 31) | ((exponent + bias.S).asUInt << 23) | roundedMantissa(23, 0)
        )
      )
    )
  )
}