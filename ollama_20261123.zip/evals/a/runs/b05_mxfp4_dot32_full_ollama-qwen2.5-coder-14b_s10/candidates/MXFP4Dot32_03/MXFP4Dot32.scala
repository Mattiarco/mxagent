import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1 to SInt(5.W)
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val base = Mux(exponent === 0.U, 1.S, (1.U(4.W) << (exponent - 1)).asSInt)
    val result = base + Mux(exponent === 0.U, 0.S, base >> 1)
    Mux(sign === 0.U, result, -result)
  }

  // Helper function to encode SInt(5.W) to FP4 E2M1
  private def encodeFP4(value: SInt): UInt = {
    val absValue = value.abs
    val sign = value < 0.S
    val exponent = Log2(absValue) + 1.U
    val mantissa = Mux(exponent === 0.U, 0.U, (absValue >> (exponent - 1)) & 1.U)
    Cat(sign, exponent, mantissa)
  }

  // Helper function to compute the product of two FP4 E2M1 values
  private def fp4Product(a: UInt, b: UInt): SInt = {
    val decodedA = decodeFP4(a)
    val decodedB = decodeFP4(b)
    decodedA * decodedB
  }

  // Helper function to compute the dot product of two MXFP4 blocks
  private def dotProduct(a: UInt, b: UInt): SInt = {
    val products = VecInit((0 until 32).map(i => fp4Product(a(4 * i + 3, 4 * i), b(4 * i + 3, 4 * i))))
    products.reduceTree(_ +& _)
  }

  // Helper function to convert SInt(14.W) to IEEE-754 binary32
  private def toFP32(value: SInt): UInt = {
    val sign = value < 0.S
    val absValue = value.abs
    val exponent = Log2(absValue) + 1.U
    val mantissa = (absValue >> (exponent - 1)) & 0x7F.U
    Cat(sign, exponent + 127.U, mantissa << 23)
  }

  // Main logic
  val aScaleNaN = io.a_scale === 0xFF.U
  val bScaleNaN = io.b_scale === 0xFF.U
  val nanOutput = aScaleNaN | bScaleNaN

  val productSum = dotProduct(io.a, io.b)
  val scaledProduct = productSum << (io.a_scale + io.b_scale - 254.U)

  val result = Mux(nanOutput, 0x7FC00000.U, toFP32(scaledProduct))

  io.y := result
}