import chisel3._
import chisel3.util._

class AdderTree extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val y = Output(SInt(14.W))  // two's complement signed integer
  })

  // Helper function to extract a signed 9-bit integer from the packed vector
  private def extractSigned(i: Int): SInt = {
    io.x(i * 9 + 8, i * 9).asSInt
  }

  // Create a vector of the 32 signed 9-bit integers
  val elements = VecInit((0 until 32).map(i => extractSigned(i)))

  // Function to perform a pairwise reduction
  private def reduceTree[T <: Bits](xs: Vec[T])(op: (T, T) => T): T = {
    if (xs.length == 1) {
      xs(0)
    } else {
      val mid = xs.length / 2
      val left = reduceTree(xs.take(mid))(op)
      val right = reduceTree(xs.drop(mid))(op)
      op(left, right)
    }
  }

  // Perform the signed addition tree reduction
  val sum = reduceTree(elements)(_ +& _)

  // Assign the result to the output port
  io.y := sum
}