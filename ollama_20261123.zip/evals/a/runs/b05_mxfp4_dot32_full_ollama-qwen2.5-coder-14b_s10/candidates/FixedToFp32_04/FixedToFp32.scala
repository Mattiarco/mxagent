import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val frac = 2
  val bias = 127
  val subnormalBias = -126
  val exponentWidth = 8
  val mantissaWidth = 23
  val inf = "b11111111000000000000000000000000".U(32.W)
  val nanPattern = "b01111111100000000000000000000000".U(32.W)
  val zeroPattern = "b00000000000000000000000000000000".U(32.W)

  // Convert x * 2^(exp - frac) to a normalized or subnormal float
  val effectiveExp = exp - frac.S
  val shiftAmount = effectiveExp + 127.S
  val shifted = (x << shiftAmount)

  // Determine if the result is subnormal
  val isSubnormal = shiftAmount < subnormalBias.S
  val subnormalShiftAmount = shiftAmount - subnormalBias.S

  // Extract mantissa and handle subnormal case
  val mantissa = WireDefault(Mux(isSubnormal, shifted >> subnormalShiftAmount, shifted >> 23))

  // Handle underflow to zero
  val underflowToZero = isSubnormal && shiftAmount < -150.S

  // Handle overflow to infinity
  val overflowToInf = shiftAmount > 128.S

  // Handle NaN
  val isInfOrNaN = io.nan | overflowToInf

  // Construct the final output
  io.y := MuxCase(zeroPattern, Seq(
    (underflowToZero, zeroPattern),
    (isInfOrNaN, inf),
    (io.nan, nanPattern)
  ))

  when (!isInfOrNaN && !underflowToZero) {
    io.y := Cat(
      x < 0.S,
      effectiveExp + bias.S,
      Fill(mantissaWidth - 23, 0.B),
      mantissa(22, 0)
    )
  }
}