import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1 to integer value in units of 1/2
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exp = value(2, 1)
    val mant = value(0)
    val subnormal = exp === 0.U

    val subnormalValue = Mux(subnormal, (mant.asSInt << -1), (Mux(mant === 0.U, 0.S, 1.S) << (exp - 1.U)))
    val normalValue = (Mux(mant === 0.U, 0.S, 1.S) << (exp - 1.U)) + Mux(mant === 1.U, (1.S << (exp - 1.U)) >> 1.U, 0.S)

    Mux(subnormal, subnormalValue, normalValue) * Mux(sign, -1.S, 1.S)
  }

  // Decode the input vectors
  val aElements = VecInit.tabulate(32)(i => decodeFP4(io.a((4 * i + 3).U, (4 * i).U)))
  val bElements = VecInit.tabulate(32)(i => decodeFP4(io.b((4 * i + 3).U, (4 * i).U)))

  // Compute the dot product, scaled by 2^(a_scale - 127) * 2^(b_scale - 127)
  val scaleA = io.a_scale.asSInt - 127.S
  val scaleB = io.b_scale.asSInt - 127.S
  val totalScale = scaleA + scaleB

  val products = VecInit.tabulate(32)(i => aElements(i) * bElements(i)) // Each product is a multiple of 0.25
  val sumProducts = products.reduceTree(_ +& _) // Sum of products is in units of 1/4

  // Scale the sum of products by 2^totalScale
  val scaledSum = sumProducts << totalScale

  // Convert the scaled sum to IEEE-754 binary32
  val result = Mux(io.a_scale === 0xFF.U || io.b_scale === 0xFF.U,
    "b11111111000000000000000000000000".U, // Canonical NaN 0x7FC00000
    ieee754Round(scaledSum, totalScale)
  )

  io.y := result

  // Helper function to round to IEEE-754 binary32 with RNE
  private def ieee754Round(value: SInt, scale: SInt): UInt = {
    val biasedExponent = scale + 127.S
    val isSubnormal = biasedExponent < 0.S

    val absValue = value.abs
    val shiftedValue = absValue >> (biasedExponent - 23.S)

    val roundBit = shiftedValue(22)
    val stickyBit = shiftedValue(21, 0).orR

    val rounding = roundBit && (stickyBit || shiftedValue(22) === 0.U)
    val roundedValue = shiftedValue + Mux(rounding, 1.U, 0.U)

    val mantissa = roundedValue(22, 0)
    val exponent = Mux(isSubnormal, 0.U, biasedExponent.asUInt)
    val sign = value < 0.S

    Cat(sign, exponent, mantissa)
  }
}