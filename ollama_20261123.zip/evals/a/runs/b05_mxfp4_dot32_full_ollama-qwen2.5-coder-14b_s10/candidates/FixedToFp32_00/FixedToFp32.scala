import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val frac = 2
  val bias = 127
  val expBias = bias - frac
  val maxExp = 255
  val minExp = 0
  val infBits = "b11111111000000000000000000000000".U
  val nanBits = "b11111111100000000000000000000000".U
  val zeroBits = "b00000000000000000000000000000000".U

  // Calculate the effective exponent
  val effectiveExp = exp + expBias.asSInt

  // Normalize the input
  val absX = io.x.abs
  val shiftAmount = Log2(absX) + 1
  val normalizedX = absX >> shiftAmount
  val normalizedExp = effectiveExp - shiftAmount.asSInt

  // Handle special cases
  val isZero = io.x === 0.S
  val isInf = normalizedExp >= maxExp.asSInt
  val isSubnormal = normalizedExp < minExp.asSInt

  // Calculate the mantissa
  val mantissaBits = Cat(Fill(23 - frac, 0.U), normalizedX(13, frac))
  val roundedMantissa = RoundToNearestEven(mantissaBits, frac)

  // Handle rounding for subnormals
  val subnormalExp = 0.U(8.W)
  val subnormalMantissa = Cat(Fill(23 - frac, 0.U), normalizedX(13, 0))

  // Construct the result
  val signBit = io.x < 0.S
  val resultExp = Mux(isInf, maxExp.U, Mux(isSubnormal, subnormalExp, normalizedExp.asUInt))
  val resultMantissa = Mux(isInf, 0.U, Mux(isSubnormal, subnormalMantissa, roundedMantissa))

  val resultBits = Cat(signBit, resultExp, resultMantissa)
  io.y := Mux(io.nan, nanBits, Mux(isZero, zeroBits, resultBits))
}

// Helper function for rounding to nearest even
def RoundToNearestEven(mantissa: UInt, frac: Int): UInt = {
  val shiftAmount = frac
  val shiftedMantissa = mantissa >> shiftAmount
  val remainder = mantissa & ((1 << shiftAmount) - 1).U
  val isHalfway = remainder === ((1 << (shiftAmount - 1)) - 1).U
  val isEven = (shiftedMantissa & 1.U) === 0.U
  val roundedMantissa = shiftedMantissa + Mux(isHalfway && !isEven, 1.U, 0.U)
  roundedMantissa
}