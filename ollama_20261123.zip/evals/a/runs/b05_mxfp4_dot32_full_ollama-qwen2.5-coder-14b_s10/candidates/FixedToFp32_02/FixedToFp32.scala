import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val totalBits = 14
  val bias = 127
  val subnormalBias = 126
  val maxExponent = 255
  val canonicalNaN = "b01111111100000000000000000000000".U

  // Helper function to compute the shift amount
  private def computeShift(exp: SInt): SInt = {
    exp - fracBits.S
  }

  // Helper function to convert fixed-point to FP32
  private def fixedToFp32(x: SInt, exp: SInt, nan: Bool): UInt = {
    val shift = computeShift(exp)
    val shiftedX = x << shift

    // Determine the sign bit
    val signBit = x < 0.S

    // Determine the exponent and mantissa
    val absX = x.abs
    val leadingOnePos = PriorityEncoder(Reverse(absX.asUInt))
    val exponent = leadingOnePos + shift + bias.S
    val mantissa = (absX >> (leadingOnePos + 1)).asUInt(23.W)

    // Handle subnormals
    val subnormalExponent = 0.S
    val subnormalMantissa = absX.asUInt(23.W)

    // Handle overflow to infinity
    val overflowExponent = maxExponent.U
    val overflowMantissa = 0.U(23.W)

    // Determine the final output
    val isZero = x === 0.S
    val isSubnormal = exponent < subnormalBias.S
    val isOverflow = exponent > maxExponent.S
    val isInf = isOverflow || (nan && absX > 0.S)
    val isCanonicalNaN = nan

    val result = WireDefault(0.U(32.W))

    when (isZero) {
      result := 0.U(32.W)
    }.elsewhen (isSubnormal) {
      result := Cat(signBit, subnormalExponent, subnormalMantissa)
    }.elsewhen (isInf) {
      result := Cat(signBit, overflowExponent, overflowMantissa)
    }.elsewhen (isCanonicalNaN) {
      result := canonicalNaN
    }.otherwise {
      result := Cat(signBit, exponent, mantissa)
    }

    result
  }

  // Assign the output
  io.y := fixedToFp32(io.x, io.exp, io.nan)
}