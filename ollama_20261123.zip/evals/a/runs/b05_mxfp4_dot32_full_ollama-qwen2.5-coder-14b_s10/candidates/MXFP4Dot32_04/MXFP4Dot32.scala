import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val isZeroOrSubnormal = exponent === 0.U
    val decodedValue = Mux(
      isZeroOrSubnormal,
      Mux(mantissa === 1.U, -0.5.S(4.W), 0.S(4.W)),
      Mux(sign === 1.U, -2.S(4.W) * exponent + 1.S(4.W) + mantissa.asSInt, 2.S(4.W) * exponent - 1.S(4.W) + mantissa.asSInt)
    )
    decodedValue
  }

  // Helper function to encode FP32
  private def encodeFP32(value: SInt): UInt = {
    val sign = value < 0.S(32.W)
    val absValue = value.abs
    val isZero = absValue === 0.S(32.W)
    val isInf = absValue >= (1 << 23).S(32.W)
    val isSubnormal = absValue < (1 << 23).S(32.W) && absValue > 0.S(32.W)

    val exponent = Mux(
      isZero, 0.U(8.W),
      Mux(isInf, 255.U(8.W), (log2Ceil(absValue.asUInt) - 1).asUInt(8.W))
    )
    val mantissa = Mux(
      isZero, 0.U(23.W),
      Mux(isInf, 0.U(23.W), absValue.asUInt >> (log2Ceil(absValue.asUInt) - 1))
    )

    Cat(sign, exponent, mantissa)
  }

  // Check for NaN in scales
  val isNaN = (io.a_scale === 0xFF.U) || (io.b_scale === 0xFF.U)
  val isNaNOutput = Mux(isNaN, 0x7FC00000.U(32.W), 0.U(32.W))

  // Decode and compute dot product
  val aElements = VecInit(Seq.fill(32) { decodeFP4(io.a(4 * _ + 3, 4 * _)) })
  val bElements = VecInit(Seq.fill(32) { decodeFP4(io.b(4 * _ + 3, 4 * _)) })
  val products = aElements.zip(bElements).map { case (a, b) => a * b }
  val sum = products.reduceTree(_ +& _)

  // Scale the sum
  val scaleA = io.a_scale.asSInt - 127.S(8.W)
  val scaleB = io.b_scale.asSInt - 127.S(8.W)
  val totalScale = scaleA + scaleB
  val scaledSum = sum << totalScale

  // Round to nearest even
  val roundedSum = scaledSum + 2.S(15.W) >> 1
  val result = encodeFP32(roundedSum)

  // Output the result
  io.y := Mux(isNaN, isNaNOutput, result)
}