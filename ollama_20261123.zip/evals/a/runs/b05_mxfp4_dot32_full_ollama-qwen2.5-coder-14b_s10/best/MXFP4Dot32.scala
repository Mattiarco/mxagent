import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Constants
  val NaN = "b11111111000000000000000000000000".U
  val Inf = "b01111111100000000000000000000000".U
  val NegInf = "b11111111100000000000000000000000".U
  val Zero = "b00000000000000000000000000000000".U

  // Extract elements from the input vectors
  val elementsA = Seq.tabulate(32)(i => io.a(4*i + 3, 4*i))
  val elementsB = Seq.tabulate(32)(i => io.b(4*i + 3, 4*i))

  // Decode FP4 E2M1 elements
  def decodeFP4(x: UInt): SInt = {
    val sign = x(3)
    val exponent = x(2, 1)
    val mantissa = x(0)
    val subnormal = exponent === 0.U
    val value = Mux(subnormal,
      Mux(mantissa === 1.U, -1.S(2.W), 0.S(2.W)),
      (Mux(mantissa === 1.U, 2.S(2.W), 1.S(2.W)) << (exponent - 1.U))
    )
    Mux(sign === 1.U, -value, value)
  }

  // Decode and compute the products
  val products = elementsA.zip(elementsB).map { case (a, b) =>
    decodeFP4(a) * decodeFP4(b)
  }

  // Sum the products exactly
  val sumProducts = VecInit(products).reduceTree(_ +& _)

  // Compute the total scale
  val totalScale = (io.a_scale.asSInt - 127.S) + (io.b_scale.asSInt - 127.S)

  // Handle NaN inputs
  when (io.a_scale === 0xFF.U || io.b_scale === 0xFF.U) {
    io.y := NaN
  } .otherwise {
    // Compute the scaled result
    val scaledResult = sumProducts << (totalScale + 1.S)

    // Convert to binary32 with rounding
    val resultFP32 = scaledResult.asFixedPoint(15, 17).asIEEE754Float()

    // Ensure zero results are +0
    io.y := Mux(resultFP32 === 0.0F.U, Zero, resultFP32)
  }
}