package cand_it00

import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed (element i at bits [32*i+31:32*i]). 32 binary32 values
    val scale = Output(UInt(8.W))    // E8M0 scale code. shared scale X
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). quantized elements
  })

  // Constants
  val INF = "b11111111100000000000000000000000".U(32.W)
  val NAN = "b11111111100000000000000000000000".U(32.W)
  val SUBNORMAL_MIN = "b00000000000000000000000000000001".U(32.W)
  val SUBNORMAL_MAX = "b00000000000000000000000000000011".U(32.W)
  val MAX_EXPONENT = 127
  val MIN_EXPONENT = -127

  // Extract individual 32-bit elements from the input vector
  val elements = Seq.fill(32) { i => io.x((i + 1) * 32 - 1, i * 32) }

  // Determine if an element is NaN or Inf
  val isInfOrNan = elements.map { x =>
    (x === INF) || (x === NAN)
  }

  // Determine if an element is zero
  val isZero = elements.map { x =>
    x === 0.U
  }

  // Extract sign, exponent, and mantissa for each element
  val signs = elements.map { x => x(31) }
  val exponents = elements.map { x => x(30, 23) }
  val mantissas = elements.map { x => x(22, 0) }

  // Handle subnormal numbers
  val subnormals = elements.map { x =>
    x < SUBNORMAL_MIN
  }

  // Calculate the absolute value of each element
  val absValues = elements.map { x =>
    x & "b01111111111111111111111111111111".U(32.W)
  }

  // Calculate the maximum absolute value
  val maxAbsValue = absValues.reduceLeft { (a, b) =>
    Mux(a > b, a, b)
  }

  // Calculate the shared exponent
  val maxExponent = log2Ceil(maxAbsValue)
  val sharedExponent = Mux(
    maxExponent > MAX_EXPONENT,
    MAX_EXPONENT,
    Mux(
      maxExponent < MIN_EXPONENT,
      MIN_EXPONENT,
      maxExponent - 2
    )
  )

  // Calculate the scale
  val scale = sharedExponent + 127

  // Handle special cases
  val allZero = isZero.reduceLeft { _ && _ }
  val anyInfOrNan = isInfOrNan.reduceLeft { _ || _ }

  val finalScale = Mux(
    anyInfOrNan,
    "b11111111".U(8.W),
    Mux(
      allZero,
      0.U(8.W),
      scale
    )
  )

  // Quantize each element
  val quantizedElements = elements.zipWithIndex.map { case (x, i) =>
    val sign = signs(i)
    val exponent = exponents(i)
    val mantissa = mantissas(i)
    val subnormal = subnormals(i)

    val shiftedValue = x >> (sharedExponent + 2)
    val roundedValue = (shiftedValue + 2.U) >> 2.U
    val saturatedValue = Mux(
      roundedValue > 6.U,
      6.U,
      Mux(
        roundedValue < -6.U,
        -6.U,
        roundedValue
      )
    )

    val finalValue = Mux(
      anyInfOrNan,
      0.U,
      Mux(
        allZero,
        sign << 3.U,
        Cat(sign, saturatedValue)
      )
    )

    finalValue
  }

  // Pack the quantized elements into the output vector
  val packedQuantizedElements = quantizedElements.zipWithIndex.map { case (q, i) =>
    q << (4 * i)
  }.reduceLeft { _ | _ }

  // Assign outputs
  io.scale := finalScale
  io.q := packedQuantizedElements
}