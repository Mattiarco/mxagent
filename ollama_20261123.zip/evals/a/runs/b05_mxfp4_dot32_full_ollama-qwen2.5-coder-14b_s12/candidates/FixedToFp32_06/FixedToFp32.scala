import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Parameters
  val w     = 14
  val frac  = 2
  val bias  = 127

  // Helper functions
  private def signBit(value: SInt): Bool = value < 0.S

  private def absValue(value: SInt): SInt = Mux(signBit(value), -value, value)

  private def isZero(value: SInt): Bool = value === 0.S

  private def isInf(value: SInt): Bool = value === (1 << (w - 1)).S

  private def encodeSubnormal(value: SInt): UInt = {
    val shiftAmount = (127 - frac).S
    val mantissa = Cat(Fill(22 - (w - frac), 0.B), absValue(value) << (shiftAmount - 1.S)).asUInt
    Cat(signBit(value).asUInt, Fill(8, 0.B), mantissa)
  }

  private def encodeNormal(value: SInt, exponent: SInt): UInt = {
    val shiftAmount = exponent - (127 - frac).S
    val mantissa = absValue(value) << shiftAmount
    val roundedMantissa = Mux(mantissa(23), mantissa + 1.U, mantissa)
    Cat(signBit(value).asUInt, (exponent - frac).asUInt, roundedMantissa(22, 0))
  }

  private def encodeInf: UInt = {
    Cat(signBit(io.x).asUInt, Fill(8, 1.B), Fill(23, 0.B))
  }

  private def encodeNaN: UInt = {
    "b11111111000000000000000000000000".U
  }

  // Main logic
  val totalExponent = io.exp + frac
  val isSubnormal = totalExponent < 1.S
  val isNormal = (totalExponent >= 1.S) & (totalExponent <= 254.S)
  val isOverflow = totalExponent > 254.S

  val result = Mux(io.nan,
    encodeNaN,
    Mux(isZero(io.x),
      0.U,
      Mux(isOverflow,
        encodeInf,
        Mux(isSubnormal,
          encodeSubnormal(io.x),
          encodeNormal(io.x, totalExponent)
        )
      )
    )
  )

  io.y := result
}