import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode an FP4 E2M1 value to its integer representation in units of 1/2
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val base = Mux(exponent === 0.U, 1.S, 2.S << exponent)
    val result = Mux(mantissa === 0.U, base >> 1, base)
    Mux(sign === 0.U, result, -result)
  }

  // Helper function to encode an integer in units of 1/4 to an FP4 E2M1 value
  private def encodeFP4(value: SInt): UInt = {
    val sign = value < 0.S
    val absValue = value.abs
    val exponent = Log2(absValue) - 1.S
    val mantissa = (absValue >> exponent) & 1.S
    Cat(sign, exponent, mantissa)
  }

  // Helper function to round a fixed-point number to binary32 with RNE
  private def roundToBinary32(value: SInt, exponent: SInt): UInt = {
    val sign = value < 0.S
    val absValue = value.abs
    val biasedExponent = exponent + 127.S
    val shiftAmount = 127.S - biasedExponent
    val shiftedValue = absValue << shiftAmount
    val roundedValue = shiftedValue + (1.S << (shiftAmount - 1))
    val fraction = (roundedValue >> 1) & 0x7FFFFF.U
    Cat(sign, biasedExponent, fraction)
  }

  // Check if a_scale or b_scale is NaN (0xFF)
  val isNaN = (io.a_scale === 0xFF.U) || (io.b_scale === 0xFF.U)

  // Decode the scales
  val aScale = io.a_scale.asSInt - 127.S
  val bScale = io.b_scale.asSInt - 127.S

  // Compute the sum of products
  val products = VecInit(Seq.fill(32) {
    val aElement = decodeFP4(io.a(4 * _.asUInt + 3, 4 * _.asUInt))
    val bElement = decodeFP4(io.b(4 * _.asUInt + 3, 4 * _.asUInt))
    aElement * bElement
  })
  val sum = products.reduceTree(_ +& _)

  // Compute the final scale
  val finalScale = aScale + bScale

  // Round the result to binary32
  val roundedResult = Mux(isNaN, 0x7FC00000.U, roundToBinary32(sum, finalScale))

  // Assign the result to the output port
  io.y := roundedResult
}