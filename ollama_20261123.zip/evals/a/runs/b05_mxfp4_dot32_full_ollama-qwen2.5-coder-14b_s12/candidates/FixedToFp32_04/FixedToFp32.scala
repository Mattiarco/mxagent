import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Parameters
  val w = 14
  val frac = 2

  // Calculate the effective exponent
  val effectiveExp = exp +& (w - frac).S(10.W)

  // Determine the absolute value and sign
  val absX = io.x.abs
  val isNegative = io.x < 0.S

  // Determine if the result is zero
  val isZero = absX === 0.S

  // Determine if the result is infinity
  val isInf = effectiveExp >= 128.S

  // Determine if the result is a subnormal
  val isSubnormal = effectiveExp < -126.S

  // Calculate the normalized exponent and mantissa
  val shiftedExp = effectiveExp +& 127.S
  val shiftedAbsX = absX << (effectiveExp +& 126.S)

  // Extract the mantissa
  val mantissa = shiftedAbsX >> (w - frac).S(10.W)

  // Round the mantissa using RNE (Round to Nearest Even)
  val stickyBit = shiftedAbsX(2) || shiftedAbsX(1) || shiftedAbsX(0)
  val roundBit = shiftedAbsX(3)
  val roundUp = roundBit && (stickyBit || (mantissa & 1.U) === 1.U)
  val roundedMantissa = Mux(roundUp, mantissa + 1.U, mantissa)

  // Handle overflow by clamping the exponent
  val finalExp = Mux(isInf, 255.U, shiftedExp)

  // Handle underflow by setting the mantissa to zero
  val finalMantissa = Mux(isSubnormal, 0.U, roundedMantissa(22, 0))

  // Construct the final result
  val infBits = Cat(isNegative, 255.U, 0.U)
  val subnormalBits = Cat(isNegative, 0.U, finalMantissa)
  val normalBits = Cat(isNegative, finalExp, finalMantissa)

  val result = Mux(io.nan, 0x7FC00000.U, 
                  Mux(isZero, 0.U, 
                      Mux(isInf, infBits, 
                          Mux(isSubnormal, subnormalBits, normalBits))))

  io.y := result
}