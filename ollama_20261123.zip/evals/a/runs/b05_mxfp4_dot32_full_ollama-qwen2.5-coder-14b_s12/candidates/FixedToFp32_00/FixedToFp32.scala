import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val expBias = 127
  val maxExp = 128
  val minExp = -126
  val infBitPattern = "b11111111000000000000000000000000".U
  val nanBitPattern = "b11111111100000000000000000000000".U
  val zeroBitPattern = "b00000000000000000000000000000000".U

  // Calculate the exact value x * 2^(exp - frac)
  val shiftedExp = exp - fracBits.S
  val shiftedValue = x << shiftedExp.asUInt

  // Determine the sign bit
  val signBit = x < 0.S

  // Calculate the exponent and mantissa
  val absValue = shiftedValue.abs
  val leadingOnePos = Log2(absValue) + 1.U
  val exponent = leadingOnePos + expBias.S - 1.S

  // Handle subnormal numbers
  val isSubnormal = exponent < minExp.S
  val subnormalExponent = 0.S
  val subnormalMantissa = shiftedValue >> (leadingOnePos - 1.U)

  // Handle overflow
  val isOverflow = exponent >= maxExp.S
  val overflowResult = Mux(signBit, infBitPattern, infBitPattern)

  // Handle NaN
  val nanResult = nanBitPattern

  // Handle zero
  val isZero = shiftedValue === 0.S
  val zeroResult = zeroBitPattern

  // Calculate the mantissa for normal numbers
  val normalMantissa = (shiftedValue >> (leadingOnePos - 1.U)) << (23 - fracBits).U

  // Select the correct result
  val result = Mux(isOverflow, overflowResult,
                  Mux(isSubnormal, Cat(subnormalExponent, subnormalMantissa),
                      Mux(isZero, zeroResult,
                          Mux(nan, nanResult,
                              Cat(signBit, exponent, normalMantissa)))))
  
  io.y := result
}