import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val bias = 127
  val exponentWidth = 8
  val mantissaWidth = 23
  val subnormalExponent = 0
  val infExponent = 255
  val canonicalNaN = "b11111111011111111111111111111111".U

  // Convert exp to unsigned and adjust by fracBits
  val expU = (io.exp + fracBits).asUInt

  // Calculate the unbiased exponent
  val unbiasedExp = expU - bias

  // Calculate the mantissa
  val xAbs = io.x.abs
  val xAbsShifted = xAbs << (mantissaWidth + 1) // Shift left by 23 + 1 to align with the binary point
  val mantissa = xAbsShifted >> 1 // Drop the hidden bit

  // Determine the sign
  val sign = io.x < 0.S

  // Handle special cases
  val isZero = io.x === 0.S
  val isInf = unbiasedExp >= infExponent
  val isSubnormal = unbiasedExp < subnormalExponent

  // Rounding logic
  val roundBit = xAbsShifted(0)
  val stickyBit = xAbsShifted.orR && (xAbsShifted(0) === 0.U)
  val carry = roundBit && (stickyBit || mantissa(0))

  // Handle rounding
  val mantissaRounded = (mantissa + carry).asUInt(mantissaWidth.W)

  // Handle overflow
  val overflow = mantissaRounded(23) && (unbiasedExp === infExponent - 1.U)

  // Determine the final exponent
  val finalExponent = Mux(isInf || overflow, infExponent.U, unbiasedExp)

  // Determine the final mantissa
  val finalMantissa = Mux(isInf || overflow, 0.U, mantissaRounded)

  // Handle subnormals
  val subnormalMantissa = xAbsShifted >> (1 - unbiasedExp)
  val subnormalMantissaRounded = (subnormalMantissa + carry).asUInt(mantissaWidth.W)
  val finalSubnormalMantissa = Mux(subnormalMantissaRounded(23), 0.U, subnormalMantissaRounded)

  // Final output
  io.y := Mux(io.nan, canonicalNaN,
    Mux(isZero, 0.U,
      Cat(
        sign,
        Mux(isSubnormal, subnormalExponent.U, finalExponent),
        Mux(isSubnormal, finalSubnormalMantissa, finalMantissa)
      )
    )
  )
}