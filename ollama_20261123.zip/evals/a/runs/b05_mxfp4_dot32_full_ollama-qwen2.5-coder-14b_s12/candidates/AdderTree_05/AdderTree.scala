import chisel3._
import chisel3.util._

class AdderTree extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val y = Output(SInt(14.W))  // two's complement signed integer
  })

  private def extractElement(vec: UInt, index: Int, width: Int): SInt = {
    val hi = index * width + width - 1
    val lo = index * width
    vec(hi, lo).asSInt
  }

  private def adderTree(inputs: Seq[SInt]): SInt = {
    if (inputs.length == 1) {
      inputs.head
    } else {
      val mid = inputs.length / 2
      val left = adderTree(inputs.take(mid))
      val right = adderTree(inputs.drop(mid))
      left + right
    }
  }

  val elements = (0 until 32).map(i => extractElement(io.x, i, 9)).toSeq
  io.y := adderTree(elements).asSInt
}