import chisel3._
import chisel3.util._

class AdderTree extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val y = Output(SInt(14.W))  // two's complement signed integer
  })

  // Helper function to extract a signed w-bit element from the input vector
  private def extractElement(index: Int, width: Int): SInt = {
    val element = io.x((index + 1) * width - 1, index * width)
    element.asSInt
  }

  // Number of elements and width of each element
  val n = 32
  val w = 9

  // Extract all elements as SInt
  val elements = VecInit((0 until n).map(i => extractElement(i, w)))

  // Helper function to perform a pairwise reduction
  private def reduceTree[T <: Data](vec: Vec[T])(op: (T, T) => T): T = {
    if (vec.length == 1) {
      vec(0)
    } else {
      val half = vec.length / 2
      val left = reduceTree(vec.take(half))(op)
      val right = reduceTree(vec.drop(half))(op)
      op(left, right)
    }
  }

  // Perform the addition tree
  val sum = reduceTree(elements)(_ +& _)

  // Output the result as SInt
  io.y := sum
}