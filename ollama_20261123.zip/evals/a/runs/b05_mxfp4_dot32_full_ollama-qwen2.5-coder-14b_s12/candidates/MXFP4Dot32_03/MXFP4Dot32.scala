import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1 to SInt(5.W)
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val base = Mux(exponent === 0.U, 1.S, 2.S << exponent)
    val result = base + Mux(mantissa === 0.U, 0.S, 1.S)
    Mux(sign === 0.U, result, -result)
  }

  // Decode the input vectors
  val a_elements = VecInit(Seq.tabulate(32)(i => decodeFP4(io.a(4 * i + 3, 4 * i))))
  val b_elements = VecInit(Seq.tabulate(32)(i => decodeFP4(io.b(4 * i + 3, 4 * i))))

  // Compute the dot product
  val product_sum = VecInit(a_elements.zip(b_elements).map { case (a, b) => a * b }).reduceTree(_ +& _)

  // Handle NaN cases
  val a_is_nan = io.a_scale === 0xFF.U
  val b_is_nan = io.b_scale === 0xFF.U
  val is_nan = a_is_nan | b_is_nan

  // Compute the final result
  val result = Mux(is_nan, "b11111111000000000000000000000000".U, {
    val scale_sum = (io.a_scale.asSInt - 127.S) + (io.b_scale.asSInt - 127.S)
    val scaled_sum = product_sum << scale_sum
    val rounded_result = scaled_sum.roundToNearestEven(32.W)
    Mux(rounded_result === 0.S, 0.U, rounded_result.asUInt)
  })

  io.y := result
}