import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to calculate the exponent from the E8M0 scale code
  private def calculateExponent(scale: UInt): SInt = {
    val exponent = scale.asSInt - 127.S
    exponent
  }

  // Calculate exponents for inputs a and b
  val expA = calculateExponent(io.a)
  val expB = calculateExponent(io.b)

  // Calculate the sum of exponents
  val expSum = expA +& expB

  // Determine if either input is NaN (0xFF)
  val nanA = io.a === 0xFF.U
  val nanB = io.b === 0xFF.U
  val nanResult = nanA | nanB

  // Assign outputs
  io.exp := Mux(nanResult, 0.S, expSum)
  io.nan := nanResult
}