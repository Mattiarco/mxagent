import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Constants
  val NaN = "b11111111000000000000000000000000".U(32.W)
  val zero = 0.U(32.W)

  // Helper function to decode FP4 E2M1
  def decodeFP4(x: UInt): SInt = {
    val sign = x(3)
    val exponent = x(2, 1)
    val mantissa = x(0)
    val subnormal = exponent === 0.U
    val value = Mux(subnormal,
      Mux(sign, -0.5.S, 0.5.S),
      Mux(sign, -(1.S + mantissa.asSInt(1.W) >> 1) << exponent, (1.S + mantissa.asSInt(1.W) >> 1) << exponent)
    )
    value
  }

  // Decode all elements of a and b
  val a_elements = VecInit((0 until 32).map(i => decodeFP4(io.a(4 * i + 3, 4 * i))))
  val b_elements = VecInit((0 until 32).map(i => decodeFP4(io.b(4 * i + 3, 4 * i))))

  // Compute the dot product
  val dot_product = a_elements.zip(b_elements).map { case (a_elem, b_elem) => a_elem * b_elem }.reduceTree(_ +& _)

  // Compute the scale factor
  val scale_factor = (io.a_scale - 127.U) +& (io.b_scale - 127.U)

  // Check for NaN in scales
  val a_is_nan = io.a_scale === 0xFF.U
  val b_is_nan = io.b_scale === 0xFF.U
  val is_nan = a_is_nan | b_is_nan

  // Compute the final result
  val result = Mux(is_nan,
    NaN,
    Mux(dot_product === 0.S,
      zero,
      {
        val scaled_product = dot_product << scale_factor
        val scaled_product_bits = scaled_product.asSInt(32.W)
        val biased_exponent = PriorityEncoder(scaled_product_bits(31, 23)) + 127.U
        val exponent = Mux(biased_exponent >= 255.U, 255.U, biased_exponent)
        val mantissa = scaled_product_bits(22, 0)
        val sign = scaled_product_bits(31)
        Cat(sign, exponent, mantissa)
      }
    )
  )

  io.y := result
}