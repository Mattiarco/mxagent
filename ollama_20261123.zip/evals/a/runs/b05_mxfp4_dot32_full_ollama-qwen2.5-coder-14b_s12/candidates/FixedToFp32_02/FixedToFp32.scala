import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val bias = 127
  val maxExp = 128
  val minExp = -126
  val infBits = "b11111111000000000000000000000000".U
  val nanBits = "b01111111100000000000000000000000".U
  val zeroBits = "b00000000000000000000000000000000".U

  // Calculate the effective exponent
  val effectiveExp = exp +& (fracBits.asSInt)

  // Determine the sign bit
  val signBit = io.x < 0.S

  // Calculate the magnitude of the fixed-point number
  val magnitude = io.x.abs.asUInt

  // Determine if the result is zero
  val isZero = (io.x === 0.S) && (effectiveExp <= minExp.asSInt)

  // Determine if the result is subnormal
  val isSubnormal = (effectiveExp <= minExp.asSInt) && (effectiveExp > (minExp - 23).asSInt)

  // Determine if the result is normal
  val isNormal = (effectiveExp >= (bias - 23).asSInt) && (effectiveExp < maxExp.asSInt)

  // Determine if the result is infinity
  val isInf = effectiveExp >= maxExp.asSInt

  // Determine if the result is NaN
  val isNaN = io.nan

  // Handle subnormal numbers
  val subnormalExp = 0.U(8.W)
  val subnormalMantissa = magnitude << ((minExp - effectiveExp + fracBits).asUInt)

  // Handle normal numbers
  val normalExp = (effectiveExp +& bias.asSInt).asUInt
  val normalMantissa = (magnitude >> fracBits.asUInt) << 9.U

  // Handle rounding
  val roundBit = (magnitude >> (fracBits - 1).asUInt) & 1.U
  val stickyBit = magnitude & ((1 << (fracBits - 1)).asUInt - 1.U)
  val shouldRoundUp = (roundBit === 1.U) && ((stickyBit =/= 0.U) || ((normalMantissa & 1.U) === 1.U))

  // Adjust mantissa for rounding
  val roundedMantissa = when(shouldRoundUp) {
    normalMantissa + 1.U
  } otherwise {
    normalMantissa
  }

  // Handle overflow in rounding
  val overflowInRounding = (roundedMantissa >> 9.U) === 1.U
  val finalMantissa = when(overflowInRounding) {
    roundedMantissa >> 1.U
  } otherwise {
    roundedMantissa
  }

  // Handle infinity
  val finalExp = when(isInf || overflowInRounding) {
    "b11111111".U
  } otherwise {
    when(isSubnormal) {
      subnormalExp
    } otherwise {
      normalExp
    }
  }

  // Handle NaN
  val finalMantissaForNaN = when(isNaN) {
    "b10000000000000".U
  } otherwise {
    finalMantissa(22, 0)
  }

  // Construct the final result
  val result = Cat(
    signBit,
    finalExp,
    finalMantissaForNaN
  )

  // Assign the output
  io.y := Mux(
    isNaN,
    nanBits,
    Mux(
      isZero,
      zeroBits,
      result
    )
  )
}