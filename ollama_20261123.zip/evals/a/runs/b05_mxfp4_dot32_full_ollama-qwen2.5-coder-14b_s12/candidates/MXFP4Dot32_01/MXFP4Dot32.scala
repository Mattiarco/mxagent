import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1 to SInt(5.W)
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val base = Mux(exponent === 0.U, 1.S, Cat(exponent.asSInt, 1.B))
    val result = Mux(sign === 0.U, base + mantissa.asSInt, -base - mantissa.asSInt)
    result
  }

  // Decode the input vectors
  val a_elements = VecInit.tabulate(32)(i => decodeFP4(io.a(4 * i + 3, 4 * i)))
  val b_elements = VecInit.tabulate(32)(i => decodeFP4(io.b(4 * i + 3, 4 * i)))

  // Compute the dot product in units of 1/4
  val dotProduct = a_elements.zip(b_elements).map { case (a, b) => a * b }.reduceTree(_ +& _)

  // Handle NaN cases
  val isANaN = io.a_scale === 0xFF.U
  val isBNaN = io.b_scale === 0xFF.U
  val isNaN = isANaN || isBNaN

  // Compute the final scale
  val scaleA = io.a_scale.asSInt - 127.S
  val scaleB = io.b_scale.asSInt - 127.S
  val totalScale = scaleA + scaleB

  // Compute the result in units of 1/4
  val resultScaled = dotProduct << totalScale

  // Convert the result to binary32
  val resultFP32 = Mux(isNaN, "b01111111100000000000000000000000".U, {
    val sign = resultScaled < 0.S
    val absResult = resultScaled.abs
    val exponent = Mux(absResult === 0.S, 0.S, Log2(absResult.asUInt) + 127.S)
    val mantissa = (absResult << (23 - exponent)).asUInt(23.W)
    Cat(sign, exponent, mantissa)
  })

  // Handle underflow to subnormals
  val underflow = exponent < 1.S
  val subnormalExponent = exponent - 1.S
  val subnormalMantissa = (absResult << (23 - subnormalExponent)).asUInt(23.W)
  val subnormalResult = Cat(sign, subnormalExponent, subnormalMantissa)

  // Final result
  io.y := Mux(underflow, subnormalResult, resultFP32)
}