import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Parameters
  val w    = 14
  val frac = 2

  // Constants
  val signBit = 31
  val expBits = 8
  val mantBits = 23
  val expBias = 127
  val maxExp = expBias + 127
  val minExp = expBias - 149
  val nanPattern = "b11111111000000000000000000000000".U
  val infPattern = "b01111111100000000000000000000000".U
  val zeroPattern = "b00000000000000000000000000000000".U

  // Convert exp to unbiased form
  val unbiasedExp = (io.exp + frac).asUInt

  // Calculate the biased exponent
  val biasedExp = unbiasedExp + expBias

  // Check if the result is zero
  val isZero = (io.x === 0.S) && (io.exp === 0.S)

  // Check if the result is subnormal
  val isSubnormal = (biasedExp < minExp.U)

  // Check if the result is infinity
  val isInf = (biasedExp > maxExp.U)

  // Handle NaN case
  val isNaN = io.nan

  // Calculate the mantissa
  val absX = io.x.abs
  val shiftAmount = unbiasedExp - expBias
  val mantissaShifted = shiftAmount.asSInt

  // Handle subnormal case
  val subnormalMantissa = absX >> (w - mantBits - 1)

  // Handle normal case
  val normalMantissa = absX >> (w - mantBits)

  // Select the mantissa based on the case
  val mantissa = Mux(isSubnormal, subnormalMantissa, normalMantissa)

  // Handle rounding
  val roundingBit = absX((w - mantBits - 2))
  val stickyBit = absX(0) | absX((w - mantBits - 2, 0)).orR
  val roundUp = roundingBit && (stickyBit || mantissa((mantBits - 1))))

  // Adjust mantissa for rounding
  val roundedMantissa = Mux(roundUp, mantissa + 1.U, mantissa)

  // Handle overflow in mantissa rounding
  val mantissaOverflow = roundedMantissa(mantBits)
  val finalMantissa = Mux(mantissaOverflow, roundedMantissa >> 1, roundedMantissa)

  // Handle exponent overflow
  val finalExp = Mux(mantissaOverflow || isInf, biasedExp + 1.U, biasedExp)

  // Determine the final sign
  val finalSign = io.x.asUInt >> (w - 1)

  // Construct the final result
  val result = Mux(
    isNaN,
    nanPattern,
    Mux(
      isInf,
      Cat(finalSign, infPattern),
      Cat(finalSign, finalExp, finalMantissa)
    )
  )

  // Assign the result to the output
  io.y := Mux(isZero, zeroPattern, result)
}