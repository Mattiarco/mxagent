import chisel3._
import chisel3.util._

class AdderTree extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val y = Output(SInt(14.W))  // two's complement signed integer
  })

  // Function to extract a signed 9-bit integer from the packed input
  private def extractSignedElement(x: UInt, index: Int, width: Int): SInt = {
    x(index * width + width - 1, index * width).asSInt
  }

  // Extract all 32 signed 9-bit elements from the input
  val elements = Seq.tabulate(32)(i => extractSignedElement(io.x, i, 9))

  // Recursive function to build an adder tree
  private def buildAdderTree(elements: Seq[SInt]): SInt = {
    if (elements.length == 1) {
      elements.head
    } else {
      val mid = elements.length / 2
      val leftSum = buildAdderTree(elements.take(mid))
      val rightSum = buildAdderTree(elements.drop(mid))
      leftSum + rightSum
    }
  }

  // Calculate the sum using the adder tree
  val sum = buildAdderTree(elements)

  // Cast the result to the required width
  io.y := sum.asSInt
}