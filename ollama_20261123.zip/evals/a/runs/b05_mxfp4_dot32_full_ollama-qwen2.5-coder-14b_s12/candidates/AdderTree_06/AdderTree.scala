import chisel3._
import chisel3.util._

class AdderTree extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val y = Output(SInt(14.W))  // two's complement signed integer
  })

  // Helper function to extract a signed 9-bit integer from the packed input
  private def extractSignedInt(x: UInt, index: Int): SInt = {
    val w = 9
    x(w * index + w - 1, w * index).asSInt
  }

  // Extract the 32 signed 9-bit integers from the packed input
  val inputs = VecInit(Seq.tabulate(32)(i => extractSignedInt(io.x, i)))

  // Helper function to perform a tree reduction
  private def reduceTree(inputs: Vec[SInt]): SInt = {
    inputs.reduceTree(_ +& _)
  }

  // Perform the adder tree reduction
  val sum = reduceTree(inputs)

  // Assign the result to the output
  io.y := sum
}