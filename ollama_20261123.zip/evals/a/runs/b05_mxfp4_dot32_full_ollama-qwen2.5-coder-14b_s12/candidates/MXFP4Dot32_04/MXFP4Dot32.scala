import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode an MXFP4 E2M1 element to its integer value in units of 1/2
  private def decodeE2M1(element: UInt): SInt = {
    val sign = element(3)
    val exponent = element(2, 1)
    val mantissa = element(0)
    val value = Cat(exponent === 0.U, mantissa) // subnormal: 0.5 * m, otherwise 1 + m/2
    val scaledValue = Mux(exponent === 0.U, value.asSInt, value.asSInt + 1.S)
    Mux(sign === 0.U, scaledValue, -scaledValue)
  }

  // Helper function to encode a binary32 float to its bit pattern
  private def encodeFP32(sign: Bool, exponent: UInt, mantissa: UInt): UInt = {
    Cat(sign, exponent, mantissa)
  }

  // Decode the scales
  val aScale = io.a_scale
  val bScale = io.b_scale

  // Check for NaN scales
  val isNaNScaleA = aScale === 0xFF.U
  val isNaNScaleB = bScale === 0xFF.U
  val isNaNResult = isNaNScaleA || isNaNScaleB

  // Initialize the sum of products
  val sumProducts = RegInit(0.S(14.W))

  // Decode and compute the dot product
  when (!isNaNResult) {
    for (i <- 0 until 32) {
      val elementA = io.a(4 * i + 3, 4 * i)
      val elementB = io.b(4 * i + 3, 4 * i)
      val valueA = decodeE2M1(elementA)
      val valueB = decodeE2M1(elementB)
      val product = valueA * valueB // Product is in units of 1/4
      sumProducts := sumProducts + product
    }
  }

  // Scale the sum of products
  val scaledSum = sumProducts << (aScale - 127.U + bScale - 127.U)

  // Convert the scaled sum to a binary32 float
  val sign = scaledSum < 0.S
  val absScaledSum = scaledSum.abs
  val exponent = Log2Ceil(absScaledSum) + 126.U
  val mantissa = (absScaledSum >> (exponent - 127.U)) & 0x7FFFFF.U

  // Handle overflow to infinity
  val isOverflow = exponent >= 0xFF.U
  val resultExponent = Mux(isOverflow, 0xFF.U, exponent)
  val resultMantissa = Mux(isOverflow, 0.U, mantissa)

  // Final result
  val result = encodeFP32(sign, resultExponent, resultMantissa)

  // Handle NaN result
  io.y := Mux(isNaNResult, 0x7FC00000.U, result)
}