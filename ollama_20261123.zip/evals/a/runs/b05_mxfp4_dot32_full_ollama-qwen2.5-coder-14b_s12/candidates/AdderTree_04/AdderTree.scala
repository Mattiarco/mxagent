import chisel3._
import chisel3.util._

class AdderTree extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val y = Output(SInt(14.W))  // two's complement signed integer
  })

  private def adderTree(inputs: Seq[SInt]): SInt = {
    if (inputs.length == 1) {
      inputs.head
    } else {
      val mid = inputs.length / 2
      val left = adderTree(inputs.take(mid))
      val right = adderTree(inputs.drop(mid))
      (left + right).asSInt
    }
  }

  // Unpack the input vector into a sequence of SInts
  val elements = (0 until 32).map { i =>
    val element = io.x((i + 1) * 9 - 1, i * 9)
    if (element(8)) {
      // If the most significant bit is 1, extend the sign
      Cat(Fill(5, element(8)), element).asSInt
    } else {
      element.asSInt
    }
  }

  // Compute the sum using the adder tree
  val sum = adderTree(elements)

  // Output the result
  io.y := sum
}