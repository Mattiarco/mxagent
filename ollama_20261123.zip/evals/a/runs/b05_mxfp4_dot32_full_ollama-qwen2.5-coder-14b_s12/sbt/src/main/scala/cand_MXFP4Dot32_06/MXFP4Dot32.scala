package cand_MXFP4Dot32_06

import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to extract and decode an FP4 E2M1 element
  private def decodeFP4(element: UInt): SInt = {
    val sign = element(3)
    val exponent = element(2, 1)
    val mantissa = element(0)

    val baseValue = Mux(exponent === 0.U, mantissa.asSInt * 1.S, (2.S << exponent.asSInt) + mantissa.asSInt)
    Mux(sign === 1.U, -baseValue, baseValue)
  }

  // Extract and decode all elements from the input vectors
  val aElements = VecInit((0 until 32).map(i => decodeFP4(io.a(4 * i + 3, 4 * i))))
  val bElements = VecInit((0 until 32).map(i => decodeFP4(io.b(4 * i + 3, 4 * i))))

  // Calculate the dot product of the two vectors
  val dotProduct = aElements.zip(bElements).map { case (a, b) => a * b }.reduceTree(_ +& _)

  // Handle NaN inputs
  val aIsNaN = io.a_scale === 0xFF.U
  val bIsNaN = io.b_scale === 0xFF.U
  val isNaN = aIsNaN | bIsNaN

  // Calculate the scale factor
  val scaleFactor = (io.a_scale.asSInt - 127.S) + (io.b_scale.asSInt - 127.S)

  // Calculate the final result
  val result = Mux(isNaN, "b11111111000000000000000000000000".U, {
    val scaledDotProduct = dotProduct << scaleFactor
    val roundedResult = scaledDotProduct.roundToNearestEven.asUInt
    val isZero = scaledDotProduct === 0.S
    Mux(isZero, 0.U, roundedResult)
  })

  io.y := result
}