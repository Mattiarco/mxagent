package cand_it06

import chisel3._
import chisel3.util._
import scala.math.{log, max, min, round}

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed (element i at bits [32*i+31:32*i]). 32 binary32 values
    val scale = Output(UInt(8.W))    // E8M0 scale code. shared scale X
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). quantized elements
  })

  // Helper function to extract a 32-bit word from the input vector
  def extractWord(index: Int): UInt = io.x((index + 1) * 32 - 1, index * 32)

  // Helper function to check if a 32-bit word is NaN or Inf
  def isNaNOrInf(word: UInt): Bool = {
    val sign = word(31)
    val exp = word(30, 23)
    val mant = word(22, 0)
    (exp === "b11111111".U) && (mant.orR || sign)
  }

  // Helper function to compute the absolute value of a 32-bit word
  def abs(word: UInt): UInt = {
    val sign = word(31)
    (word ^ (sign << 31)) - sign
  }

  // Helper function to compute the floor(log2) of a 32-bit word
  def floorLog2(word: UInt): Int = {
    if (word == 0.U) 0
    else (log(word.toDouble) / log(2.0)).toInt
  }

  // Helper function to encode a value in E2M1 format
  def e2m1Encode(value: Double, sign: Bool): UInt = {
    val absValue = math.abs(value)
    val exponent = math.floor(math.log(absValue) / math.log(2.0)).toInt
    val mantissa = (absValue / math.pow(2.0, exponent)).round.toInt & 0x3
    val encoded = (sign << 2) | (exponent & 0x3) | (mantissa & 0x3)
    UInt(encoded)
  }

  // Determine if any input is NaN or Inf
  val anyNaNOrInf = (0 until 32).map(i => isNaNOrInf(extractWord(i))).reduce(_ || _)

  // Compute the shared exponent
  val maxAbs = (0 until 32).map(i => abs(extractWord(i))).reduce(_ max _)
  val shared = Mux(anyNaNOrInf, -127, max(floorLog2(maxAbs) - 2, -127))
  val scale = shared + 127.U

  // Quantize each element
  val q = Wire(Vec(32, UInt(4.W)))
  for (i <- 0 until 32) {
    val word = extractWord(i)
    val sign = word(31)
    val isNaNOrInf = isNaNOrInf(word)
    val absValue = abs(word).toDouble
    val quantizedValue = Mux(isNaNOrInf, 0.0, absValue / math.pow(2.0, shared.toDouble))
    val saturatedValue = min(max(quantizedValue, -6.0), 6.0)
    val roundedValue = round(saturatedValue)
    q(i) := Mux(isNaNOrInf, 0.U, e2m1Encode(roundedValue, sign))
  }

  // Pack the quantized values into a single 128-bit vector
  io.q := Cat(q.reverse)

  // Handle the special cases
  when (anyNaNOrInf) {
    io.scale := 0xFF.U
    for (i <- 0 until 32) {
      q(i) := 0.U
    }
  } .otherwise {
    io.scale := scale
  }
}