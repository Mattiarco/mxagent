import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1 to SInt(5.W) in units of 1/2
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val base = Mux(exponent === 0.U, 0.S, Cat(exponent, mantissa).asSInt)
    Mux(sign === 0.U, base, -base)
  }

  // Helper function to encode SInt(5.W) in units of 1/2 to FP4 E2M1
  private def encodeFP4(value: SInt): UInt = {
    val absValue = value.abs
    val exponent = Mux(absValue === 0.S, 0.U, Log2(absValue) + 1.U)
    val mantissa = Mux(exponent === 0.U, 0.U, (absValue >> (exponent - 1.U)) & 1.U)
    Cat(value < 0.S, exponent, mantissa)
  }

  // Decode the input blocks
  val a_elements = VecInit((0 until 32).map(i => decodeFP4(io.a(4 * i + 3, 4 * i))))
  val b_elements = VecInit((0 until 32).map(i => decodeFP4(io.b(4 * i + 3, 4 * i))))

  // Compute the dot product
  val products = a_elements.zip(b_elements).map { case (a, b) => a * b }
  val sum = products.reduceTree(_ +& _)

  // Handle NaN cases
  val a_isNaN = io.a_scale === 0xFF.U
  val b_isNaN = io.b_scale === 0xFF.U
  val isNaN = a_isNaN | b_isNaN

  // Compute the scale factor
  val scaleFactor = (io.a_scale - 127.U) +& (io.b_scale - 127.U)

  // Compute the final result
  val result = Mux(isNaN, "b11111111000000000000000000000000".U, {
    val scaledSum = sum << scaleFactor
    val roundedResult = RoundToNearestEven(scaledSum, 24)
    val sign = scaledSum < 0.S
    val absValue = roundedResult.abs
    val exponent = Mux(absValue === 0.S, 0.U, Log2(absValue) + 1.U)
    val mantissa = Mux(exponent === 0.U, 0.U, (absValue >> (exponent - 1.U)) & 0x7FFFFF.U)
    Cat(sign, exponent, mantissa)
  })

  io.y := result
}

// Helper function to round to nearest even
private def RoundToNearestEven(value: SInt, fractionalBits: Int): SInt = {
  val integerPart = value >> fractionalBits
  val fractionalPart = value & ((1 << fractionalBits) - 1).S
  val half = (1 << (fractionalBits - 1)).S
  val isHalf = fractionalPart === half
  val isLessThanHalf = fractionalPart < half
  val isGreaterThanHalf = fractionalPart > half
  val isEven = integerPart(0) === 0.U
  val rounded = Mux(isLessThanHalf, integerPart, Mux(isGreaterThanHalf, integerPart + 1.S, Mux(isEven, integerPart, integerPart + 1.S)))
  rounded << fractionalBits
}