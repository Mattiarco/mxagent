import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to convert E8M0 scale code to exponent
  private def e8m0ToExponent(code: UInt): SInt = {
    val exponent = code.asSInt - 127.S
    exponent
  }

  // Check if the input is NaN (0xFF)
  val aIsNaN = io.a === 0xFF.U
  val bIsNaN = io.b === 0xFF.U

  // Calculate the exponent of the product
  val expA = e8m0ToExponent(io.a)
  val expB = e8m0ToExponent(io.b)
  val expSum = expA +& expB

  // Determine the NaN flag
  io.nan := aIsNaN | bIsNaN

  // Set the exponent to 0 if either input is NaN
  io.exp := Mux(io.nan, 0.S, expSum)
}