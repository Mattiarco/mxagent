import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1 to SInt(5.W)
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val baseValue = Mux(exponent === 0.U, mantissa.asSInt, (1.U(2.W) + mantissa.asSInt) << exponent)
    Mux(sign === 1.U, -baseValue, baseValue)
  }

  // Helper function to encode SInt(5.W) to FP4 E2M1
  private def encodeFP4(value: SInt): UInt = {
    val absValue = value.abs
    val exponent = Log2(absValue + 1.U) - 1.U
    val mantissa = (absValue >> exponent) - 1.U
    val sign = value < 0.S
    Cat(sign, exponent, mantissa)
  }

  // Decode the input vectors into SInt(5.W) representations
  val a_elements = VecInit.tabulate(32)(i => decodeFP4(io.a(4 * i + 3, 4 * i)))
  val b_elements = VecInit.tabulate(32)(i => decodeFP4(io.b(4 * i + 3, 4 * i)))

  // Compute the exact dot product in units of 1/4
  val dotProduct = VecInit(a_elements.zip(b_elements).map { case (a, b) => a * b }).reduceTree(_ +& _)

  // Handle NaN cases
  val isNaN = (io.a_scale === 0xFF.U) || (io.b_scale === 0xFF.U)
  val nanResult = 0x7FC00000.U

  // Compute the scale factor
  val scaleFactor = (io.a_scale - 127.U) + (io.b_scale - 127.U)

  // Compute the final result
  val result = WireDefault(nanResult)
  when(!isNaN) {
    // Scale the dot product to binary32
    val scaledProduct = dotProduct << (scaleFactor - 15.U)
    // Convert to binary32 with rounding
    val sign = scaledProduct < 0.S
    val absScaledProduct = scaledProduct.abs
    val exponent = Log2(absScaledProduct + 1.U) - 1.U
    val mantissa = (absScaledProduct >> (exponent - 23.U)) & 0x7FFFFF.U
    val roundedMantissa = Mux(mantissa(23) === 1.U && (mantissa(22, 0) === 0.U || mantissa(22) === 1.U), mantissa + 1.U, mantissa)
    val resultBits = Cat(sign, exponent, roundedMantissa)
    result := resultBits
  }

  io.y := result
}