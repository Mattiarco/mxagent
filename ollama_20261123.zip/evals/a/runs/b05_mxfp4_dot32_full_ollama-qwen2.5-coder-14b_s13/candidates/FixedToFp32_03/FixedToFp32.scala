import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val frac = 2
  val bias = 127
  val maxExp = 128
  val minExp = -126
  val maxExpBits = 255
  val nanBits = "b11111111000000000000000000000000".U
  val zeroBits = "b00000000000000000000000000000000".U

  // Calculate the effective exponent
  val effectiveExp = io.exp - frac

  // Calculate the unbiased exponent
  val unbiasedExp = effectiveExp + bias

  // Handle NaN case
  when (io.nan) {
    io.y := nanBits
  } .otherwise {
    // Handle zero case
    when (io.x === 0.S) {
      io.y := zeroBits
    } .otherwise {
      // Calculate the absolute value of x
      val absX = io.x.abs

      // Calculate the shift amount for normalization
      val leadingOnePos = PriorityEncoder(Reverse(absX.asUInt))
      val shiftAmount = leadingOnePos - 1.U

      // Normalize the mantissa
      val normalizedMantissa = (absX << (31.U - shiftAmount)) >> 31.U

      // Calculate the biased exponent for normalized form
      val normalizedExp = unbiasedExp + shiftAmount

      // Handle overflow
      when (normalizedExp >= maxExp) {
        io.y := Cat(io.x < 0.S, "b11111111".U, "b00000000000000000000000".U)
      } .otherwise {
        // Handle underflow
        when (normalizedExp < minExp) {
          // Calculate the subnormal mantissa
          val subnormalMantissa = absX << (127.U - unbiasedExp)
          io.y := Cat(io.x < 0.S, "b00000000".U, subnormalMantissa(22, 0))
        } .otherwise {
          // Normal form
          val expBits = normalizedExp.asUInt(8.W)
          io.y := Cat(io.x < 0.S, expBits, normalizedMantissa(22, 0))
        }
      }
    }
  }
}