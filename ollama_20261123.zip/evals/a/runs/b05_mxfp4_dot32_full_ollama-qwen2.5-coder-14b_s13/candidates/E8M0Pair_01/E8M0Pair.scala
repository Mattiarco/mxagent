import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to check if a scale code is NaN
  private def isNaN(scale: UInt): Bool = {
    scale === 0xFF.U
  }

  // Calculate the exponent for a given scale code
  private def calcExponent(scale: UInt): SInt = {
    (scale.asSInt - 127.S).zext
  }

  // Determine if either input is NaN
  val nanA = isNaN(io.a)
  val nanB = isNaN(io.b)

  // Calculate the exponent for each input
  val expA = calcExponent(io.a)
  val expB = calcExponent(io.b)

  // Calculate the combined exponent
  val exp = expA + expB

  // Determine if the output should be NaN
  io.nan := nanA || nanB

  // If either input is NaN, set the exponent to 0
  io.exp := Mux(io.nan, 0.S(10.W), exp)
}