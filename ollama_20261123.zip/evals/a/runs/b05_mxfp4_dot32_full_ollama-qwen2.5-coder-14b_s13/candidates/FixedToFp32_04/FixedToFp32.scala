import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Parameters
  val w     = 14
  val frac  = 2

  // Helper function to convert fixed-point to FP32
  private def fixedToFp32(x: SInt, exp: SInt, frac: Int): UInt = {
    // Adjust exponent
    val adjustedExp = exp - frac.U(10.W)

    // Calculate the absolute value of x
    val absX = x.abs

    // Calculate the mantissa and exponent shift
    val (mantissa, shift) = {
      val shift = Mux(adjustedExp >= 0.S, 0.S, -adjustedExp)
      val mantissa = (absX >> shift).asUInt(w.W)
      (mantissa, shift)
    }

    // Handle overflow and underflow cases
    val isOverflow = adjustedExp >= 128.S
    val isUnderflow = adjustedExp < -126.S

    // Handle canonical NaN
    val isCanonicalNaN = io.nan

    // Handle zero case
    val isZero = x === 0.S

    // Determine the sign bit
    val sign = x < 0.S

    // Calculate the final exponent and mantissa
    val finalExp = Mux(
      isOverflow,
      "hFF".U(8.W), // Infinity
      Mux(
        isUnderflow,
        0.U(8.W),    // Subnormal
        (adjustedExp + 127.S).asUInt(8.W) // Normal
      )
    )

    val finalMantissa = Mux(
      isOverflow,
      0.U(23.W),    // Infinity
      Mux(
        isUnderflow,
        (absX << (126 - shift)).asUInt(23.W), // Subnormal
        (mantissa << (23 - w)).asUInt(23.W) // Normal
      )
    )

    // Handle rounding to nearest even (RNE)
    val roundedMantissa = {
      val roundBit = mantissa(w - frac - 1)
      val stickyBit = (mantissa >> (frac + 1)).orR
      val lsb = finalMantissa(0)
      val increment = (roundBit && (stickyBit || lsb)).asUInt(23.W)
      finalMantissa + increment
    }

    // Handle canonical NaN
    val result = Mux(
      isCanonicalNaN,
      "h7FC00000".U(32.W), // Canonical NaN
      Mux(
        isZero,
        0.U(32.W),        // Zero
        Cat(sign, finalExp, roundedMantissa)
      )
    )

    result
  }

  // Convert input to FP32
  io.y := fixedToFp32(io.x, io.exp, frac)
}