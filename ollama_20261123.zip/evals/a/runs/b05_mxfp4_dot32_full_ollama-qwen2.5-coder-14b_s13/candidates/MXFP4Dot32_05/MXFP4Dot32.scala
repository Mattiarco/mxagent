import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1 format
  private def decodeFP4E2M1(x: UInt): SInt = {
    val sign = x(3)
    val exponent = x(2, 1)
    val mantissa = x(0)
    val value = Mux(exponent === 0.U,
      Mux(sign, -0.5.S, 0.5.S),
      Mux(sign, -((1.U + mantissa.asUInt) << exponent - 1.U), (1.U + mantissa.asUInt) << exponent - 1.U)
    )
    value * 2.S // Convert to units of 0.25
  }

  // Decode the scales and check for NaN
  val isANaN = io.a_scale === 0xFF.U
  val isBNaN = io.b_scale === 0xFF.U
  val isNaN = isANaN | isBNaN

  val scaleA = io.a_scale - 127.U
  val scaleB = io.b_scale - 127.U

  // Decode the vectors of FP4 E2M1 values
  val aElements = VecInit(Seq.tabulate(32)(i => decodeFP4E2M1(io.a(4 * i + 3, 4 * i))))
  val bElements = VecInit(Seq.tabulate(32)(i => decodeFP4E2M1(io.b(4 * i + 3, 4 * i))))

  // Compute the dot product exactly (in units of 0.25)
  val products = aElements.zip(bElements).map { case (a, b) => a * b }
  val sumProducts = products.reduceTree(_ +& _)

  // Apply the scales
  val scaledSum = sumProducts * (scaleA + scaleB).asSInt

  // Convert the scaled sum to IEEE-754 binary32
  val result = Mux(isNaN,
    "b01111111100000000000000000000000".U, // Canonical NaN 0x7FC00000
    VecInit(Seq.fill(24)(0.U(1.W)) ++ scaledSum.asUInt(24.W)).asUInt
  )

  io.y := result
}