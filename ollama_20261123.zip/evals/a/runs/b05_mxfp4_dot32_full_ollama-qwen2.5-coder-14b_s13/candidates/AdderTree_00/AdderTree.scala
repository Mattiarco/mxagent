import chisel3._
import chisel3.util._

class AdderTree extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(288.W))  // two's complement signed integer, vector of 32 x 9-bit elements packed (element i at bits [9*i+8:9*i])
    val y = Output(SInt(14.W))  // two's complement signed integer
  })

  private def extractElement(x: UInt, index: Int, width: Int): SInt = {
    x(index * width + width - 1, index * width).asSInt
  }

  private def adderTree(elements: Seq[SInt]): SInt = {
    if (elements.size == 1) {
      elements.head
    } else {
      val mid = elements.size / 2
      val leftSum = adderTree(elements.take(mid))
      val rightSum = adderTree(elements.drop(mid))
      leftSum +& rightSum
    }
  }

  val elements = (0 until 32).map(i => extractElement(io.x, i, 9))
  io.y := adderTree(elements)
}