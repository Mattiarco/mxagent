import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val expBias = 127
  val expMax = 255
  val nanValue = "b11111111000000000000000000000000".U(32.W)
  val zeroValue = "b00000000000000000000000000000000".U(32.W)

  // Convert the fixed-point number to a signed integer representation of the mantissa and exponent
  val shiftedX = (io.x << (10.W - fracBits)) // Shift x left by 8 to account for the fractional bits
  val xAbs = shiftedX.abs
  val leadingOnePos = PriorityEncoder(Reverse(xAbs.orR)) // Find the position of the leading one
  val mantissa = (shiftedX >> (leadingOnePos - 22)) // Shift to get the mantissa bits
  val effectiveExp = expBias + leadingOnePos - fracBits + io.exp

  // Determine if the result is subnormal, normal, or overflow
  val isSubnormal = effectiveExp < 0
  val isNormal = effectiveExp >= 0 && effectiveExp < expMax
  val isOverflow = effectiveExp >= expMax

  // Construct the FP32 bit pattern
  val signBit = io.x < 0
  val expField = Mux(isSubnormal, 0.U(8.W), Mux(isOverflow, expMax.U(8.W), effectiveExp.asUInt(8.W)))
  val mantissaField = Mux(isSubnormal, (xAbs << (-effectiveExp - 1)) >> 10, mantissa)

  val result = Cat(signBit, expField, mantissaField)

  // Handle NaN case
  io.y := Mux(io.nan, nanValue, result)
}