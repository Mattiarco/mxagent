import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode MXFP4 element to its integer value in units of 1/2
  private def decodeMXFP4(element: UInt): SInt = {
    val sign    = element(3)
    val exponent = element(2, 1)
    val mantissa = element(0)
    val subnormal = exponent === 0.U
    val value = Mux(subnormal,
      Cat(sign, 0.U(2.W), 0.U(1.W)).asSInt * Cat(1.U(1.W), mantissa).asSInt,
      Cat(sign, 1.U(2.W), 0.U(1.W)).asSInt * (1.U + Cat(1.U(1.W), mantissa)).asSInt * (2.U ** (exponent - 1.U))
    )
    value
  }

  // Helper function to encode integer value in units of 1/4 to MXFP4 format
  private def encodeMXFP4(value: SInt): UInt = {
    val sign    = value(15)
    val absValue = value.abs
    val exponent = Log2(absValue) + 1.U
    val mantissa = (absValue >> (exponent - 1.U)) & 1.U
    Cat(sign, exponent - 1.U, mantissa).asUInt
  }

  // Extract elements from the input vectors
  val a_elements = Seq.tabulate(32)(i => a(4*i + 3, 4*i))
  val b_elements = Seq.tabulate(32)(i => b(4*i + 3, 4*i))

  // Decode MXFP4 elements to their integer values in units of 1/2
  val a_values = a_elements.map(decodeMXFP4)
  val b_values = b_elements.map(decodeMXFP4)

  // Compute products of corresponding elements
  val products = a_values.zip(b_values).map { case (a, b) => a * b }

  // Sum all products exactly (no intermediate rounding)
  val sum = VecInit(products).reduceTree(_ +& _)

  // Compute the final result scaling factor
  val scaleFactor = 2.U ** (a_scale - 127.U) * 2.U ** (b_scale - 127.U)

  // Compute the unscaled result
  val unscaledResult = sum * scaleFactor

  // Convert unscaled result to binary32 format with RNE rounding
  val result = ieeeFloatFromFixed(unscaledResult)

  // Handle NaN cases
  val isNaNA = a_scale === 0xFF.U
  val isNaNB = b_scale === 0xFF.U
  val isNaN = isNaNA || isNaNB
  val nanResult = 0x7FC00000.U

  // Final output with NaN handling
  io.y := Mux(isNaN, nanResult, result)
}

// Helper function to convert fixed-point to IEEE-754 binary32 with RNE rounding
private def ieeeFloatFromFixed(value: SInt): UInt = {
  val sign = value(15)
  val absValue = value.abs
  val exponent = Log2(absValue) + 1.U
  val mantissa = (absValue >> (exponent - 1.U)) & 0x7FFFFF.U
  val roundedMantissa = (mantissa + 0x000000.U) & 0xFFFFFF.U  // RNE rounding
  val result = Cat(sign, exponent - 127.U, roundedMantissa)
  result
}