import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val fracBits = 2
  val mantissaBits = 23
  val exponentBits = 8
  val exponentBias = 127
  val subnormalThreshold = -126
  val infExponent = 255
  val canonicalNaN = "b11111111000000000000000000000000".U

  // Calculate the full exponent
  val fullExp = exp - fracBits

  // Calculate the magnitude of the number
  val absX = x.abs
  val shiftAmount = fullExp - (31 - fracBits)

  // Normalize the number to get the mantissa and exponent
  val (mantissa, expAdjust) = {
    when (shiftAmount >= 0) {
      val shifted = (absX << shiftAmount)(31, 0)
      (shifted >> (31 - mantissaBits), shiftAmount)
    } .otherwise {
      val shifted = (absX >> (-shiftAmount))(31, 0)
      (shifted, 0)
    }
  }

  // Determine the final exponent
  val finalExp = fullExp + expAdjust + exponentBias

  // Handle special cases
  val isZero = x === 0.S
  val isNaN = io.nan
  val isSubnormal = finalExp < 0
  val isInf = finalExp >= infExponent

  // Round the mantissa to 23 bits using RNE
  val roundedMantissa = {
    val lowerBits = mantissa(22, 0)
    val stickyBit = mantissa(23, 0).orR
    val roundBit = mantissa(23)
    val increment = (roundBit && (stickyBit || mantissa(24) === 1.U)) || (roundBit && mantissa(24) === 0.U && lowerBits =/= 0.U)
    lowerBits + Mux(increment, 1.U, 0.U)
  }

  // Construct the final result
  io.y := Mux(isNaN, canonicalNaN,
    Mux(isZero, 0.U,
      Mux(isInf, Cat(0.U(1.W), Fill(7, 1.U), Fill(23, 0.U)),
        Mux(isSubnormal,
          Cat(0.U(1.W), 0.U(7.W), roundedMantissa << (-(finalExp + 1))),
          Cat(0.U(1.W), finalExp(7, 0), roundedMantissa))
    )
  )

  // Handle the sign bit
  io.y := Mux(x < 0.S, io.y | Fill(32, 1.U), io.y)
}