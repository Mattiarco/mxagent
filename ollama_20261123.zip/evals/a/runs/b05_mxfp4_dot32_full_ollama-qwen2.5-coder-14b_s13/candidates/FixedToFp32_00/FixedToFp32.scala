import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val frac = 2
  val expBias = 127
  val maxExp = 128
  val minExp = -126
  val maxExpField = 255
  val nanValue = "b11111111000000000000000000000000".U
  val infValue = "b01111111100000000000000000000000".U
  val zeroValue = "b00000000000000000000000000000000".U

  // Calculate the exact value x * 2^(exp - frac)
  val scaledExp = exp - frac.U
  val scaledValue = x << scaledExp

  // Determine the sign bit
  val sign = x < 0.S

  // Determine the exponent field
  val absScaledValue = scaledValue.abs
  val expField = scaledExp + expBias.U

  // Handle overflow and underflow
  val isOverflow = expField >= maxExp.U
  val isUnderflow = expField <= minExp.U

  // Handle NaN
  val isNaN = io.nan

  // Handle zero
  val isZero = scaledValue === 0.S

  // Determine the mantissa field
  val mantissaBits = absScaledValue(22, 0)
  val stickyBit = absScaledValue(23, 0).orR

  // Rounding logic (RNE)
  val roundBit = absScaledValue(23)
  val roundedMantissa = (mantissaBits + roundBit + stickyBit).asUInt(23.W)
  val carryOut = roundedMantissa(23)

  // Adjust exponent and mantissa for rounding
  val finalExpField = expField + carryOut
  val finalMantissaBits = roundedMantissa(22, 0)

  // Construct the final FP32 value
  val fp32Value = WireDefault(zeroValue)

  when (isNaN) {
    fp32Value := nanValue
  } .elsewhen (isOverflow) {
    fp32Value := infValue
  } .elsewhen (isUnderflow) {
    val subnormalExp = expField - expBias.U + 1.U
    val subnormalMantissa = absScaledValue >> (expBias.U - subnormalExp)
    fp32Value := Cat(sign, subnormalExp, subnormalMantissa)
  } .otherwise {
    fp32Value := Cat(sign, finalExpField, finalMantissaBits)
  }

  io.y := fp32Value
}