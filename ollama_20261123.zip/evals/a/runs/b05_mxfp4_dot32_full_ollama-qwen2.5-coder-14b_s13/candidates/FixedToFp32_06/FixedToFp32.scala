import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  private val w = 14
  private val frac = 2

  private def toBinary32(x: SInt, exp: SInt, nan: Bool): UInt = {
    val absX = x.abs
    val sign = x < 0.S

    // Calculate the biased exponent
    val biasedExp = exp + (127 - frac).S

    // Handle NaN case
    when (nan) {
      return "b11111111000000000000000000000000".U
    }

    // Handle zero case
    when (x === 0.S) {
      return "b00000000000000000000000000000000".U
    }

    // Calculate the mantissa
    val shiftAmount = biasedExp - 127.S + frac.S
    val shiftedX = (absX << shiftAmount).asUInt
    val mantissa = shiftedX(23, 0).asUInt

    // Handle overflow
    when (biasedExp >= 255.S) {
      return (sign << 31) + "b11111111000000000000000000000000".U
    }

    // Handle underflow to subnormal
    when (biasedExp < 0.S) {
      val subnormalShift = 126.S - biasedExp
      val subnormalMantissa = (absX << subnormalShift).asUInt(23.W)
      val subnormalBits = (sign << 31) + subnormalMantissa
      return subnormalBits
    }

    // Normal case
    val normalBits = (sign << 31) + (biasedExp.asUInt << 23) + mantissa
    normalBits
  }

  io.y := toBinary32(io.x, io.exp, io.nan)
}