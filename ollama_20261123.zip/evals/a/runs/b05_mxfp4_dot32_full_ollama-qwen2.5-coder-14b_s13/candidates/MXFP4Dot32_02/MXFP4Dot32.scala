import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1
  private def decodeFP4(value: UInt): SInt = {
    val sign = value(3)
    val exponent = value(2, 1)
    val mantissa = value(0)
    val isSubnormal = exponent === 0.U
    val subnormalValue = Cat(sign, 0.U(2.W), mantissa).asSInt
    val normalValue = Cat(sign, exponent + 1.U, mantissa).asSInt
    Mux(isSubnormal, subnormalValue, normalValue)
  }

  // Decode the input blocks
  val aElements = VecInit.tabulate(32)(i => decodeFP4(io.a(4*i+3, 4*i)))
  val bElements = VecInit.tabulate(32)(i => decodeFP4(io.b(4*i+3, 4*i)))

  // Calculate the products and sum them
  val products = aElements.zip(bElements).map { case (a, b) => a * b }
  val sum = VecInit(products).reduceTree(_ +& _)

  // Handle NaN cases
  val isANan = io.a_scale === 0xFF.U
  val isBNan = io.b_scale === 0xFF.U
  val isNan = isANan || isBNan
  val nanResult = "b11111111000000000000000000000000".U

  // Calculate the final scale
  val aBias = io.a_scale - 127.U
  val bBias = io.b_scale - 127.U
  val finalBias = aBias + bBias

  // Calculate the final result
  val scaledSum = sum << (finalBias + 2.U)
  val result = Mux(isNan, nanResult, scaledSum.asUInt)

  // Round the result to binary32
  val roundedResult = ieee754Round(result)

  // Output the result
  io.y := roundedResult
}

// Helper function to round to IEEE-754 binary32
private def ieee754Round(value: UInt): UInt = {
  val sign = value(31)
  val exponent = value(30, 23)
  val mantissa = value(22, 0)
  val stickyBit = (value & "b11111111111111111111111".U) =/= 0.U
  val roundBit = mantissa(22)
  val guardBit = mantissa(21)
  val roundUp = roundBit && (guardBit || stickyBit)
  val newMantissa = Mux(roundUp, mantissa + 1.U, mantissa)
  val overflow = newMantissa(23)
  val newExponent = exponent + Cat(overflow, 0.U(7.W))
  val infinityExponent = "b11111111".U
  val infinityResult = Cat(sign, infinityExponent, "b0".U(23.W))
  val overflowResult = Mux(sign === 0.U, infinityResult, ~infinityResult)
  val underflowResult = Cat(sign, 0.U(8.W), "b0".U(23.W))
  val underflow = newExponent === 0.U
  val finalResult = Mux(overflow, overflowResult, Mux(underflow, underflowResult, Cat(sign, newExponent, newMantissa(22, 0))))
  finalResult
}