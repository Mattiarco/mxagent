import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Helper function to decode FP4 E2M1 format
  private def decodeFP4(fp4: UInt): SInt = {
    val sign = fp4(3).asSInt
    val exponent = fp4(2, 1)
    val mantissa = fp4(0)
    val isSubnormal = exponent === 0.U

    val subnormalValue = sign * (mantissa.asSInt >> 1) // -0.5 * m
    val normalValue = sign * (SInt(2.W) << (exponent - 1.U)) * (1.S + mantissa.asSInt >> 1) // (-1)^s * 2^(e-1) * (1 + m/2)

    Mux(isSubnormal, subnormalValue, normalValue)
  }

  // Decode all elements of the input vectors
  val a_elements = VecInit.tabulate(32)(i => decodeFP4(io.a(4 * i + 3, 4 * i)))
  val b_elements = VecInit.tabulate(32)(i => decodeFP4(io.b(4 * i + 3, 4 * i)))

  // Compute the exact dot product
  val dotProduct = a_elements.zip(b_elements).map { case (a, b) => a * b }.reduceTree(_ +& _)

  // Handle NaN cases
  val isANan = io.a_scale === 0xFF.U
  val isBNan = io.b_scale === 0xFF.U
  val isNaN = isANan || isBNan

  // Compute the final scale factor
  val aFactor = (SInt(2.W) << (io.a_scale - 127.U))
  val bFactor = (SInt(2.W) << (io.b_scale - 127.U))
  val scaleFactor = aFactor * bFactor

  // Compute the final result
  val scaledResult = dotProduct * scaleFactor

  // Convert scaled result to binary32
  val fp32Result = when(isNaN) {
    "b11111111000000000000000000000000".U // NaN 0x7FC00000
  } .otherwise {
    val sign = scaledResult < 0.S
    val absResult = scaledResult.abs

    // Determine the exponent and mantissa
    val exp = Log2(absResult) + 126.U
    val mantissa = (absResult >> (exp - 127.U)) & "b01111111111".U

    // Round to nearest even
    val roundingBit = (absResult >> (exp - 128.U)) & 1.U
    val stickyBit = (absResult & ("b111" << (exp - 129.U))).orR
    val roundUp = roundingBit === 1.U && (stickyBit || (absResult & ("b1" << (exp - 128.U))) === 0.U)

    val roundedMantissa = if (roundUp) {
      Mux(mantissa === "b11111111111".U, 0.U, mantissa + 1.U)
    } else {
      mantissa
    }

    // Handle overflow to infinity
    val isOverflow = exp > 254.U
    val resultExp = Mux(isOverflow, 255.U, exp)
    val resultMantissa = Mux(isOverflow, 0.U, roundedMantissa)

    Cat(sign, resultExp, resultMantissa)
  }

  io.y := fp32Result
}