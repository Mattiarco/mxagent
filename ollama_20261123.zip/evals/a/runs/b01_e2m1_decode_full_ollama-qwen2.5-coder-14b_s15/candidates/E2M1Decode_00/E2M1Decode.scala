import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Helper function to decode the E2M1 code
  private def decodeE2M1(code: UInt): SInt = {
    val sign = code(3)
    val exponent = code(2, 1)
    val mantissa = code(0)

    // Lookup table for the exponent values
    val exponentValues = VecInit(
      Seq(
        0.S(3.W),  // 00 -> 0
        1.S(3.W),  // 01 -> 1
        2.S(3.W),  // 10 -> 2
        3.S(3.W)   // 11 -> 3
      )
    )

    // Decode the exponent value
    val expValue = exponentValues(exponent)

    // Calculate the value
    val value = Mux(
      exponent === 0.U,
      Mux(mantissa === 0.U, 0.S(4.W), 1.S(4.W)),  // Subnormal: 0.5
      (1.S << expValue) + Mux(mantissa === 1.U, 1.S << expValue, 0.S)  // Normal: 2^(e-1) * (1 + m/2)
    )

    // Apply the sign
    Mux(sign === 0.U, value, -value)
  }

  // Decode the input and multiply by 2
  io.y := decodeE2M1(io.a).asSInt * 2.S
}