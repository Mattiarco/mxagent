import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Helper function to decode E2M1 to signed fixed-point
  private def decodeE2M1(input: UInt): SInt = {
    val sign = input(3)
    val exponent = input(2, 1)
    val mantissa = input(0)

    val value = Mux(exponent === 0.U,
      Mux(mantissa === 0.U, 0.S, 1.S), // Subnormal: 0.5
      (2.S << (exponent - 1.U)) + Mux(mantissa === 0.U, 0.S, 1.S) // Normal: 2^(e-1) * (1 + m/2)
    )

    Mux(sign === 0.U, value, -value) // Apply sign
  }

  // Decode the input E2M1 code
  io.y := decodeE2M1(io.a)
}