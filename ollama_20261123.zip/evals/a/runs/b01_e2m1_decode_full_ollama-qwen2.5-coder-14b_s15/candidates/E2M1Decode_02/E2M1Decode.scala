import chisel3._
import chisel3.util._

class E2M1Decode extends RawModule {
  val io = FlatIO(new Bundle {
    val a = Input(UInt(4.W))   // FP4 E2M1 code. one FP4 E2M1 element
    val y = Output(SInt(5.W))  // two's complement signed integer in units of 2^-1. exact value of a; y = value * 2
  })

  // Decode the E2M1 code
  val sign = io.a(3)
  val exponent = io.a(2, 1)
  val mantissa = io.a(0)

  // Handle the special case where the code is 0b0000 or 0b1000 (both should produce 0)
  val zeroCode = (exponent === 0.U) & (mantissa === 0.U)

  // Calculate the value for non-zero codes
  val baseValue = Mux(exponent === 0.U, 1.S, Cat(exponent, 0.B).asSInt << 1) // 2^(e-1) * 2
  val mantissaValue = Mux(mantissa === 0.U, 1.S, 2.S) // 1 + m/2
  val value = baseValue * mantissaValue

  // Apply the sign
  val signedValue = Mux(sign === 0.U, value, -value)

  // Output the result, zeroing out special codes
  io.y := Mux(zeroCode, 0.S, signedValue)
}