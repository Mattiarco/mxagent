import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Constants
  val NaN = "b11111111000000000000000000000000".U
  val Inf = "b01111111100000000000000000000000".U
  val NegInf = "b11111111100000000000000000000000".U
  val Zero = "b00000000000000000000000000000000".U
  val NegZero = "b10000000000000000000000000000000".U

  // Check for NaN inputs
  when (io.a_scale === 0xFF.U || io.b_scale === 0xFF.U) {
    io.y := NaN
  } .otherwise {
    // Decode FP4 elements
    val a_elements = VecInit.tabulate(32) { i => io.a(4*i + 3, 4*i) }
    val b_elements = VecInit.tabulate(32) { i => io.b(4*i + 3, 4*i) }

    // Compute the dot product
    val dotProduct = Wire(SInt(14.W)) // Sum of products, scaled by 1/4
    dotProduct := 0.S

    for (i <- 0 until 32) {
      val a_val = Cat(Fill(2, a_elements(i)(3)), a_elements(i)(2, 0)) // Convert FP4 to signed 3-bit integer
      val b_val = Cat(Fill(2, b_elements(i)(3)), b_elements(i)(2, 0)) // Convert FP4 to signed 3-bit integer
      dotProduct := dotProduct + (a_val.asSInt * b_val.asSInt)
    }

    // Scale the dot product
    val scaleA = io.a_scale.asSInt - 127.S
    val scaleB = io.b_scale.asSInt - 127.S
    val totalScale = scaleA + scaleB

    // Convert dotProduct to binary32
    val scaledDotProduct = dotProduct << (totalScale + 2.S).asUInt // Scale by 4 and adjust for binary32 exponent

    // Handle overflow and underflow
    when (scaledDotProduct > 0x7FFFFFFF.S) {
      io.y := Inf
    } .elsewhen (scaledDotProduct < -0x7FFFFFFF.S) {
      io.y := NegInf
    } .otherwise {
      // Convert to binary32
      val sign = scaledDotProduct < 0.S
      val absValue = scaledDotProduct.abs
      val exponent = 127 + log2Ceil(absValue.asUInt) - 23
      val mantissa = (absValue >> (log2Ceil(absValue.asUInt) - 23)).asUInt(23.W)

      // Round to nearest even
      val stickyBit = (absValue & 0x7FFFFF.U) =/= 0.U
      val roundBit = (absValue & 0x400000.U) =/= 0.U
      val carry = (stickyBit && roundBit) || (roundBit && (mantissa & 1.U) =/= 0.U)
      val roundedMantissa = (mantissa + Cat(carry, 0.U(22.W))).asUInt(23.W)

      // Handle overflow after rounding
      when (roundedMantissa(23) === 1.U) {
        exponent := exponent + 1.U
        roundedMantissa := roundedMantissa(22, 0)
      }

      // Construct the final binary32 result
      io.y := Cat(sign, exponent(7, 0), roundedMantissa(22, 0))
    }
  }
}