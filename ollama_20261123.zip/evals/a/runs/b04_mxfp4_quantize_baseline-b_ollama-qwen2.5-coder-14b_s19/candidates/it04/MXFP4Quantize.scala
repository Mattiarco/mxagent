import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed (element i at bits [32*i+31:32*i]). 32 binary32 values
    val scale = Output(UInt(8.W))    // E8M0 scale code. shared scale X
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). quantized elements
  })

  // Helper function to extract sign, exponent, and mantissa from a binary32 value
  def extractSignExpMant(x: UInt): (Bool, UInt, UInt) = {
    val sign = x(31)
    val exp = x(30, 23)
    val mant = x(22, 0)
    (sign, exp, mant)
  }

  // Helper function to check if a binary32 value is NaN or Inf
  def isNaNOrInf(exp: UInt, mant: UInt): Bool = {
    exp === "b11111111".U && mant.orR
  }

  // Helper function to compute the floor(log2) of a binary32 value
  def floorLog2(x: UInt): SInt = {
    val sign = x(31)
    val exp = x(30, 23)
    val mant = x(22, 0)

    if (exp === "b00000000".U && mant === 0.U) { // Zero
      -127.S
    } else if (isNaNOrInf(exp, mant)) { // NaN or Inf
      -128.S
    } else {
      val biasedExp = exp.asSInt
      val leadingOnePos = log2Ceil(mant.orR.asUInt + 1.U)
      (biasedExp - 127 - leadingOnePos).asSInt
    }
  }

  // Compute the shared exponent
  val maxLog2 = RegInit(-128.S)
  val allZero = Wire(Bool())
  allZero := true.B

  for (i <- 0 until 32) {
    val xi = io.x(32 * i + 31, 32 * i)
    val signi = xi(31)
    val expi = xi(30, 23)
    val manthi = xi(22, 0)

    val isZero = expi === "b00000000".U && manthi === 0.U
    allZero := allZero && isZero

    when (!isZero && !isNaNOrInf(expi, manthi)) {
      val log2i = floorLog2(xi)
      maxLog2 := Mux(log2i > maxLog2, log2i, maxLog2)
    }
  }

  val shared = Mux(allZero, -127.S, maxLog2 - 2.S)
  val clampedShared = Mux(shared < -127.S, -127.S, Mux(shared > 127.S, 127.S, shared))
  io.scale := (clampedShared + 127.S).asUInt

  // Quantize each element
  val qVec = Wire(Vec(32, UInt(4.W)))

  for (i <- 0 until 32) {
    val xi = io.x(32 * i + 31, 32 * i)
    val signi = xi(31)
    val expi = xi(30, 23)
    val manthi = xi(22, 0)

    val isZero = expi === "b00000000".U && manthi === 0.U
    val isNaNOrInf = expi === "b11111111".U && manthi.orR

    when (isNaNOrInf) {
      qVec(i) := 0.U
    } .otherwise {
      val log2i = floorLog2(xi)
      val shift = clampedShared - log2i
      val shiftedMant = manthi << shift.asUInt

      val roundedMant = (shiftedMant + (1 << 11)).asSInt >> 11
      val saturatedMant = roundedMant.clamp(-6.S, 6.S)

      qVec(i) := Cat(signi, saturatedMant.asUInt(3.W))
    }
  }

  io.q := qVec.asUInt
}