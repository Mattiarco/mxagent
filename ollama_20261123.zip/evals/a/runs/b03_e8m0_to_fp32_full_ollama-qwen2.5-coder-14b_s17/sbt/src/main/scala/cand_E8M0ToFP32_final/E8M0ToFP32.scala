package cand_E8M0ToFP32_final

import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Helper function to convert E8M0 to FP32
  private def e8m0ToFP32(x: UInt): UInt = {
    Mux(x === 0xFF.U,
      // NaN case
      0x7FC00000.U,
      Mux(x === 0.U,
        // Subnormal case
        0x00400000.U,
        // Normal case
        {
          val exponent = x - 127.U
          val sign = 0.U(1.W) // Always positive
          val mantissa = 0.U(23.W)
          val biasedExponent = exponent + 127.U
          Cat(sign, biasedExponent, mantissa)
        }
      )
    )
  }

  // Connect the output
  io.y := e8m0ToFP32(io.x)
}