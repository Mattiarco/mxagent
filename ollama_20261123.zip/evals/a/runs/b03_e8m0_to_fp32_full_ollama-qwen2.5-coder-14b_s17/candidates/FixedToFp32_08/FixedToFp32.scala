import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Parameters
  val w = 14
  val frac = 2

  // Convert exp from signed to unsigned
  val unsignedExp = io.exp.asUInt

  // Calculate the total exponent for the floating-point representation
  val totalExp = unsignedExp +& (127 - frac).asUInt

  // Determine the sign of the result
  val signBit = io.x < 0.S

  // Handle NaN case
  when (io.nan) {
    io.y := "b01111111100000000000000000000000".U
  } .otherwise {
    // Calculate the absolute value of x
    val absX = io.x.abs.asUInt

    // Calculate the mantissa
    val shiftedX = (absX << (23 - frac)).asUInt
    val mantissa = shiftedX(22, 0)

    // Handle underflow and overflow cases
    when (totalExp === 0.U || totalExp === 255.U) {
      // Underflow or overflow
      when (totalExp === 0.U) {
        // Underflow: subnormal number
        io.y := Cat(signBit, totalExp, mantissa)
      } .otherwise {
        // Overflow: infinity or NaN
        io.y := Cat(signBit, "b11111111".U, Fill(23, 1.U))
      }
    } .otherwise {
      // Normal number
      io.y := Cat(signBit, totalExp, mantissa)
    }
  }
}