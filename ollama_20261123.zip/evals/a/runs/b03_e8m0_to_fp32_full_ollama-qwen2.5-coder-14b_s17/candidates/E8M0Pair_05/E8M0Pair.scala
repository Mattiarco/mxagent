import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to calculate the exponent part
  private def calculateExp(scale: UInt): SInt = {
    val exponent = scale - 127.U
    exponent.asSInt
  }

  // Check if either input is NaN (0xFF)
  val aIsNaN = io.a === 0xFF.U
  val bIsNaN = io.b === 0xFF.U

  // Calculate the exponents for both inputs
  val expA = calculateExp(io.a)
  val expB = calculateExp(io.b)

  // Sum of the exponents
  val expSum = expA +& expB

  // Determine the NaN flag
  io.nan := aIsNaN | bIsNaN

  // Assign the exponent output, with 0 if either input is NaN
  io.exp := Mux(io.nan, 0.S, expSum)
}