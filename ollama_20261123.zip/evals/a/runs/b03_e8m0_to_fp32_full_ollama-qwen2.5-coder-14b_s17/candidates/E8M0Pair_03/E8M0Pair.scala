import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to check if a scale code is NaN
  private def isNaN(code: UInt): Bool = code === 0xFF.U

  // Calculate the exponent for a given scale code
  private def calculateExponent(code: UInt): SInt = {
    val exponent = code.asSInt - 127.S
    exponent
  }

  // Determine if either input is NaN
  io.nan := isNaN(io.a) || isNaN(io.b)

  // Calculate the exponent for the product of two scales
  val expA = calculateExponent(io.a)
  val expB = calculateExponent(io.b)

  // If either input is NaN, the exponent must be 0
  io.exp := Mux(io.nan, 0.S, expA + expB)
}