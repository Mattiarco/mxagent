import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val frac = 2
  val expBias = 127
  val maxExp = 255
  val subnormalBias = 149
  val nanValue = "b11111111000000000000000000000000".U
  val infValue = "b01111111100000000000000000000000".U
  val zeroValue = "b00000000000000000000000000000000".U

  // Calculate the exact value x * 2^(exp - frac)
  val shiftedExp = exp - frac
  val shiftedValue = x << shiftedExp

  // Determine the sign bit
  val signBit = shiftedValue < 0.S

  // Calculate the absolute value of the shifted value
  val absValue = shiftedValue.abs

  // Calculate the exponent and mantissa
  val (mantissa, expValue) = {
    when (absValue === 0.S) {
      (0.U(23.W), 0.U(8.W))
    } .otherwise {
      val leadingOnePos = PriorityEncoder(Reverse(absValue.asUInt))
      val expValue = leadingOnePos + expBias.U - shiftedExp.asUInt
      val mantissaBits = absValue.asUInt >> (leadingOnePos + 1.U)
      val mantissa = mantissaBits(22, 0)
      (mantissa, expValue)
    }
  }

  // Handle subnormal numbers
  val isSubnormal = expValue < 1.U
  val subnormalExp = 0.U(8.W)
  val subnormalMantissa = absValue.asUInt >> (subnormalBias.U - shiftedExp.asUInt)

  // Handle overflow
  val isOverflow = expValue > maxExp.U
  val overflowValue = Mux(signBit, infValue, infValue)

  // Handle NaN
  val nanValue = "b11111111000000000000000000000000".U

  // Select the final result
  val result = Mux(io.nan, nanValue,
    Mux(isOverflow, overflowValue,
      Mux(isSubnormal, Cat(signBit, subnormalExp, subnormalMantissa),
        Cat(signBit, expValue, mantissa)
      )
    )
  )

  io.y := result
}