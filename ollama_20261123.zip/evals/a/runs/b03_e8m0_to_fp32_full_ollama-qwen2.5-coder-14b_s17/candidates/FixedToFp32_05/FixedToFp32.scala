import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  val frac = 2
  val w = 14

  // Helper function to convert SInt to UInt and handle negative values
  private def sIntToUInt(x: SInt, width: Int): UInt = {
    val zextX = x.zext(width.W)
    val isNeg = x < 0.S
    val absX = (x.asUInt + 1.U)(width - 1, 0)
    Mux(isNeg, (~absX + 1.U)(width - 1, 0), zextX)
  }

  // Calculate the total exponent
  val totalExp = exp +& (w - 1 - frac).S

  // Determine the sign bit
  val signBit = io.x < 0.S

  // Calculate the biased exponent
  val biasedExp = totalExp +& 127.S

  // Handle overflow to infinity
  val overflow = biasedExp >= 255.S

  // Handle underflow to subnormal or zero
  val underflow = biasedExp < 1.S

  // Calculate the mantissa
  val mantissaBits = (io.x.abs * 1.S)(w - 1 - frac, 0)
  val roundedMantissa = RoundNearEven(mantissaBits, 23 - frac)

  // Construct the final FP32 representation
  val normal = Cat(signBit, biasedExp, roundedMantissa)
  val subnormal = {
    val adjustedExp = biasedExp +& 126.S
    val subnormalMantissa = mantissaBits << (adjustedExp - 1.S)
    Cat(signBit, 0.U(8.W), subnormalMantissa(22, 0))
  }
  val zero = Cat(signBit, 0.U(8.W), 0.U(23.W))
  val inf = Cat(signBit, 255.U(8.W), 0.U(23.W))
  val nan = Cat(false.B, 255.U(8.W), 1.U(23.W)) // Canonical NaN

  // Select the appropriate output
  io.y := Mux(io.nan, nan,
    Mux(overflow, inf,
      Mux(underflow, {
        when(totalExp === -127.S) {
          zero
        }.otherwise {
          subnormal
        }
      }, normal)
    )
  )
}

// Helper class for rounding near even
class RoundNearEven(in: UInt, width: Int) extends Module {
  val io = FlatIO(new Bundle {
    val in = Input(in)
    val out = Output(UInt(width.W))
  })

  val half = (1.U << (in.getWidth - width - 1))
  val sticky = (in & (half - 1.U)) =/= 0.U
  val roundBit = (in >> (in.getWidth - width - 1)) & 1.U
  val carry = (roundBit === 1.U) && ((in >> (in.getWidth - width - 2)) & 1.U === 1.U) || sticky
  io.out := (in >> (in.getWidth - width)) +& Cat(carry, 0.U(width - 1))
}