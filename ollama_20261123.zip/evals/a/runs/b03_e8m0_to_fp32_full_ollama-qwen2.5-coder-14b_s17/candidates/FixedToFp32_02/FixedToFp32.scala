import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Parameters
  val w = 14
  val frac = 2

  // Helper function to round to nearest even
  def roundToNearestEven(mantissa: UInt, stickyBit: Bool): UInt = {
    val roundBit = mantissa(22)
    val oddBit = mantissa(21)
    val lsb = mantissa(20)
    val guardBit = mantissa(19)
    val roundUp = (roundBit & (oddBit | stickyBit | (lsb & guardBit)))
    Mux(roundUp, mantissa + 1.U, mantissa)
  }

  // Calculate the effective exponent
  val effectiveExp = exp - frac.asSInt

  // Calculate the biased exponent
  val biasedExp = effectiveExp + 127.S

  // Handle NaN case
  when (io.nan) {
    io.y := 0x7FC00000.U
  } .otherwise {
    // Calculate the absolute value of the input
    val absX = x.abs

    // Determine the leading one position
    val leadingOnePos = PriorityEncoder(Reverse(absX.asUInt))

    // Calculate the mantissa
    val mantissaBits = absX >> (leadingOnePos - (31 - frac).S)
    val mantissa = Cat(Fill(1, 1.B), mantissaBits(22, 0))

    // Determine the sticky bit
    val stickyBit = absX(leadingOnePos - (32 - frac).S - 1, 0).orR

    // Handle overflow
    when (biasedExp >= 255.S) {
      io.y := Mux(x < 0.S, 0xFF800000.U, 0x7F800000.U)
    } .elsewhen (biasedExp <= 0.S) {
      // Handle underflow to subnormal
      val subnormalExp = biasedExp + 126.S
      val subnormalShift = 126.S - subnormalExp
      val subnormalMantissa = absX >> subnormalShift
      io.y := Cat(Fill(9, 0.B), subnormalMantissa(22, 0))
    } .otherwise {
      // Normal case
      val roundedMantissa = roundToNearestEven(mantissa, stickyBit)
      val signBit = x < 0.S
      io.y := Cat(signBit, biasedExp.asUInt, roundedMantissa)
    }
  }
}