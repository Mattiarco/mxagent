import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to check if a or b is NaN
  private def isNaN(x: UInt): Bool = x === 0xFF.U

  // Helper function to compute the exponent part
  private def computeExp(x: UInt): SInt = {
    (x.asSInt - 127.S).asSInt
  }

  // Check if either a or b is NaN
  io.nan := isNaN(io.a) || isNaN(io.b)

  // Compute the exponent of the product of the two scales
  io.exp := Mux(io.nan, 0.S, computeExp(io.a) + computeExp(io.b))
}