import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to check if a value is NaN (0xFF)
  private def isNaN(value: UInt): Bool = value === 0xFF.U

  // Calculate the exponent for a given E8M0 scale code
  private def calculateExponent(value: UInt): SInt = {
    // Subtract 127 from the value and convert to signed integer
    (value.asSInt - 127.S)
  }

  // Calculate the exponent for inputs a and b
  val expA = calculateExponent(io.a)
  val expB = calculateExponent(io.b)

  // Calculate the sum of the exponents
  val expSum = expA + expB

  // Determine if either input is NaN
  val nanA = isNaN(io.a)
  val nanB = isNaN(io.b)

  // Output the exponent and NaN flag
  io.exp := Mux(nanA || nanB, 0.S, expSum)
  io.nan := nanA || nanB
}