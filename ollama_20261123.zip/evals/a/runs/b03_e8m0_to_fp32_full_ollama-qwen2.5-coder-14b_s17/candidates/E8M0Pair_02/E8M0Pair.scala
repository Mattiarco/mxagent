import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to determine if a value is NaN (0xFF)
  private def isNaN(x: UInt): Bool = x === 0xFF.U

  // Calculate the exponent for a given scale code
  private def calculateExp(x: UInt): SInt = {
    val bias = 127.U
    (x.asSInt - bias.asSInt).asSInt
  }

  // Determine if either input is NaN
  val nanA = isNaN(io.a)
  val nanB = isNaN(io.b)

  // Calculate the exponent for each input
  val expA = calculateExp(io.a)
  val expB = calculateExp(io.b)

  // Calculate the combined exponent
  val expCombined = expA +& expB

  // Determine the NaN flag
  val nan = nanA | nanB

  // Assign outputs
  io.exp := Mux(nan, 0.S(10.W), expCombined)
  io.nan := nan
}