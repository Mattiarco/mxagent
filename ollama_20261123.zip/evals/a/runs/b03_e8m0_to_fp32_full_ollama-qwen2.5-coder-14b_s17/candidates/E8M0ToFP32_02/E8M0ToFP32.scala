import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Constants
  val NaN = "b11111111100000000000000000000000".U
  val Subnormal = "b00000000000000000000000000000000".U
  val Bias = 127

  // Handle NaN case
  when (io.x === 0xFF.U) {
    io.y := NaN
  } .elsewhen (io.x === 0.U) {
    // Handle subnormal case (2^-127)
    io.y := Subnormal
  } .otherwise {
    // Calculate the exponent
    val exponent = io.x - Bias.U

    // Handle underflow (exponent < -126)
    when (exponent < -126.S) {
      io.y := Subnormal
    } .otherwise {
      // Handle normal case (exponent >= -126)
      val biasedExponent = exponent + Bias.U
      val mantissa = 0.U(23.W) // Zero mantissa for normal numbers

      // Construct the FP32 bit pattern
      io.y := Cat(biasedExponent, mantissa)
    }
  }
}