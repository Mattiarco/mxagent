import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  val fracBits = 2

  // Calculate the unbiased exponent
  val unbiasedExp = io.exp - (fracBits.asSInt + 127.S)

  // Calculate the significand
  val significandBits = 23
  val significand = io.x.asUInt >> fracBits

  // Determine the sign bit
  val sign = io.x < 0.S

  // Calculate the biased exponent
  val biasedExp = unbiasedExp + 127.S

  // Handle special cases
  val isZero = significand === 0.U && unbiasedExp === -127.S
  val isInf = biasedExp > 254.S
  val isSubnormal = biasedExp === 0.S && significand =/= 0.U

  // Handle NaN
  val isNaN = io.nan

  // Handle rounding
  val roundingBits = io.x.asUInt(fracBits + 1, fracBits)
  val roundUp = roundingBits >= 4.U

  // Determine the final significand and exponent
  val finalSignificand = WireDefault(significand(22, 0))
  val finalExponent = WireDefault(biasedExp)

  when (isZero) {
    finalSignificand := 0.U
    finalExponent := 0.U
  } .elsewhen (isInf) {
    finalSignificand := 0.U
    finalExponent := 255.U
  } .elsewhen (isSubnormal) {
    val subnormalSignificand = significand >> (-biasedExp)
    finalSignificand := subnormalSignificand(22, 0)
    finalExponent := 0.U
  } .elsewhen (isNaN) {
    finalSignificand := 0x7FFFFF.U
    finalExponent := 255.U
  } .otherwise {
    when (roundUp) {
      finalSignificand := significand + 1.U
      when (finalSignificand(23)) {
        finalExponent := biasedExp + 1.S
      }
    }
  }

  // Construct the final result
  io.y := Cat(sign, finalExponent, finalSignificand)
}