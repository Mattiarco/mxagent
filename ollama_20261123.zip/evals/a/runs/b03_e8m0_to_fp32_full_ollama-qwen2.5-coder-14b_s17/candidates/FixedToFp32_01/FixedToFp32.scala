import chisel3._
import chisel3.util._

class FixedToFp32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x   = Input(SInt(14.W))   // two's complement signed integer in units of 2^-2
    val exp = Input(SInt(10.W))   // two's complement signed integer
    val nan = Input(Bool())       // 1-bit flag
    val y   = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern
  })

  // Constants
  val frac = 2
  val expBias = 127
  val maxExp = 255
  val infBits = "b11111111000000000000000000000000".U
  val nanBits = "b11111111100000000000000000000000".U

  // Calculate the normalized exponent
  val totalExp = exp +& (frac.asSInt - expBias.asSInt)
  val normalizedExp = totalExp +& 127.asSInt

  // Calculate the significand
  val significand = Cat(0.U(1.W), x.abs.asUInt(13.W)).asUInt

  // Handle NaN case
  when (io.nan) {
    io.y := nanBits
  } .elsewhen (x === 0.S) {
    io.y := 0.U
  } .elsewhen (normalizedExp < 0.asSInt) {
    // Subnormal case
    val subnormalShift = -normalizedExp
    val subnormalBits = significand >> subnormalShift
    io.y := Cat(0.U(1.W), subnormalBits(22, 0))
  } .elsewhen (normalizedExp >= maxExp.asSInt) {
    // Infinity case
    io.y := infBits
  } .otherwise {
    // Normal case
    val roundBits = significand(23, 0)
    val roundedSignificand = (significand + roundBits).asUInt >> 1.U
    io.y := Cat(io.x(13), normalizedExp.asUInt(8.W), roundedSignificand(22, 0))
  }
}