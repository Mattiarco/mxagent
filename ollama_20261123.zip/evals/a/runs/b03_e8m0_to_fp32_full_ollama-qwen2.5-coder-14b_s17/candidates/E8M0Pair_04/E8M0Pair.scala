import chisel3._
import chisel3.util._

class E8M0Pair extends RawModule {
  val io = FlatIO(new Bundle {
    val a   = Input(UInt(8.W))    // E8M0 scale code
    val b   = Input(UInt(8.W))    // E8M0 scale code
    val exp = Output(SInt(10.W))  // two's complement signed integer
    val nan = Output(Bool())      // 1-bit flag
  })

  // Helper function to calculate the exponent from E8M0 scale code
  private def calculateExponent(code: UInt): SInt = {
    val exponent = code.asSInt - 127.S
    exponent
  }

  // Calculate exponents for inputs a and b
  val expA = calculateExponent(io.a)
  val expB = calculateExponent(io.b)

  // Calculate the sum of exponents
  val expSum = expA + expB

  // Determine if either input is NaN (0xFF)
  val nanA = io.a === 0xFF.U
  val nanB = io.b === 0xFF.U

  // Set nan flag if either input is NaN
  io.nan := nanA || nanB

  // If either input is NaN, set exp to 0
  io.exp := Mux(io.nan, 0.S, expSum)
}