import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Constants
  val nan32 = "b01111111100000000000000000000000".U(32.W)
  val subnormalMin32 = "b00000000000000000000000000000001".U(32.W)
  val zero32 = "b00000000000000000000000000000000".U(32.W)

  // Handle NaN case
  when (io.x === 0xFF.U) {
    io.y := nan32
  } .otherwise {
    // Calculate the exponent for the FP32 output
    val exponent = io.x - 127.U

    // Handle subnormal case (exponent < -126)
    val isSubnormal = exponent < -126.U
    val subnormalExp = exponent + 127.U

    // Handle normal case
    val normalExp = exponent + 127.U
    val normalMantissa = 0.U(23.W) // Zero mantissa for normal numbers

    // Select between subnormal and normal
    io.y := Mux(isSubnormal,
      Cat(subnormalExp, normalMantissa),
      Cat(normalExp, normalMantissa)
    )
  }
}