// generato da mxagent.synth.wrapper per E8M0ToFP32 (b03_e8m0_to_fp32)
module mxagent_ppa_wrap(input clk, input din, output dout);
  reg [7:0] sh;
  always @(posedge clk) sh <= {sh[6:0], din};
  wire [31:0] o_y;
  E8M0ToFP32 dut(.x(sh[7:0]), .y(o_y));
  reg [31:0] q;
  always @(posedge clk) q <= {o_y};
  assign dout = ^q;
endmodule
