import chisel3._
import chisel3.util._

class E8M0ToFP32 extends RawModule {
  val io = FlatIO(new Bundle {
    val x = Input(UInt(8.W))    // E8M0 scale code
    val y = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. 2^(x-127) as IEEE binary32; NaN -> 0x7FC00000
  })

  // Constants
  val NaN = "b11111111100000000000000000000000".U(32.W)
  val SUBNORMAL = "b00000000000000000000000001000000".U(32.W)

  // Handle NaN case
  when (io.x === "b11111111".U) {
    io.y := NaN
  } .elsewhen (io.x === 0.U) {
    // Handle subnormal case for 2^-127
    io.y := SUBNORMAL
  } .otherwise {
    // Calculate the exponent for normal numbers
    val exponent = io.x - 127.U
    val biasedExponent = exponent + 127.U

    // Construct the IEEE-754 binary32 representation
    io.y := Cat(biasedExponent, 0.U(23.W))
  }
}