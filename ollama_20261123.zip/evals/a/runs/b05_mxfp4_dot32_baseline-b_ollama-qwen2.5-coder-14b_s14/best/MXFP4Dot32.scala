import chisel3._
import chisel3.util._

class MXFP4Dot32 extends RawModule {
  val io = FlatIO(new Bundle {
    val a_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block A
    val a       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block A
    val b_scale = Input(UInt(8.W))    // E8M0 scale code. shared scale of block B
    val b       = Input(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). elements of block B
    val y       = Output(UInt(32.W))  // IEEE-754 binary32 bit pattern. dot product rounded once to binary32
  })

  // Constants
  val NaN = "b11111111000000000000000000000000".U(32.W)
  val Inf = "b01111111100000000000000000000000".U(32.W)
  val NegInf = "b11111111100000000000000000000000".U(32.W)
  val Zero = "b00000000000000000000000000000000".U(32.W)
  val NegZero = "b10000000000000000000000000000000".U(32.W)

  // Check for NaN inputs
  when (io.a_scale === 0xFF.U || io.b_scale === 0xFF.U) {
    io.y := NaN
  } .otherwise {
    // Unpack the FP4 elements
    val a_elements = VecInit.tabulate(32) { i => (io.a >> (4 * i)).asSInt(2.W) }
    val b_elements = VecInit.tabulate(32) { i => (io.b >> (4 * i)).asSInt(2.W) }

    // Compute the dot product
    val dot_product = a_elements.zip(b_elements).map { case (a, b) => a * b }.reduce(_ + _)

    // Compute the scale factor
    val scale_factor = (io.a_scale - 127.U) + (io.b_scale - 127.U)

    // Compute the scaled result
    val scaled_result = dot_product << (scale_factor + 2.U) // Each product is a multiple of 0.25

    // Convert to binary32
    val result = scaled_result.asSInt(16.W).asFixedPoint(14.W, 2.W).asIEEE754(32.W)

    // Handle underflow and overflow
    when (scaled_result < 0.S) {
      io.y := NegZero
    } .elsewhen (scaled_result > 0.S) {
      io.y := Zero
    } .otherwise {
      io.y := result
    }
  }
}