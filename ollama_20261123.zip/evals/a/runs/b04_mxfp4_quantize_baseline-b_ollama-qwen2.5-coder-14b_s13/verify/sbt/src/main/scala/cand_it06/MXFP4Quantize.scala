package cand_it06

import chisel3._
import chisel3.util._

class MXFP4Quantize extends RawModule {
  val io = FlatIO(new Bundle {
    val x     = Input(UInt(1024.W))  // IEEE-754 binary32 bit pattern, vector of 32 x 32-bit elements packed (element i at bits [32*i+31:32*i]). 32 binary32 values
    val scale = Output(UInt(8.W))    // E8M0 scale code. shared scale X
    val q     = Output(UInt(128.W))  // FP4 E2M1 code, vector of 32 x 4-bit elements packed (element i at bits [4*i+3:4*i]). quantized elements
  })

  // Helper function to extract a 32-bit element from the input vector
  def getElement(input: UInt, index: Int): UInt = {
    (input >> (index * 32)).asUInt(32.W)
  }

  // Helper function to check if a 32-bit value is NaN or Inf
  def isNaNOrInf(value: UInt): Bool = {
    val sign = value(31)
    val exp = value(30, 23)
    val mant = value(22, 0)
    (exp === "b11111111".U) && (mant =/= 0.U)
  }

  // Helper function to calculate the floor(log2) of a 32-bit value
  def floorLog2(value: UInt): UInt = {
    val exp = value(30, 23)
    val mant = value(22, 0)
    when (exp === 0.U) {
      // Subnormal number
      val leadingZeros = leadingZeros(mant)
      (23.U - leadingZeros - 1.U)
    }.otherwise {
      // Normal number
      (exp - 127.U)
    }
  }

  // Helper function to extract the sign of a 32-bit value
  def getSign(value: UInt): Bool = {
    value(31)
  }

  // Helper function to extract the mantissa of a 32-bit value
  def getMantissa(value: UInt): UInt = {
    value(22, 0)
  }

  // Calculate the shared exponent
  val maxLog2 = Wire(UInt(8.W))
  val allZero = Wire(Bool())
  val anyNaNOrInf = Wire(Bool())

  allZero := true.B
  anyNaNOrInf := false.B
  maxLog2 := -128.U

  for (i <- 0 until 32) {
    val element = getElement(io.x, i)
    when (!isNaNOrInf(element) && element =/= 0.U) {
      allZero := false.B
      val log2Value = floorLog2(element)
      when (log2Value > maxLog2) {
        maxLog2 := log2Value
      }
    }.otherwise {
      anyNaNOrInf := true.B
    }
  }

  val shared = Mux(allZero, -127.S, Mux(anyNaNOrInf, 127.S, (maxLog2 - 2.S).asUInt))
  val scale = shared + 127.U

  // Quantize each element
  val q = Wire(UInt(128.W))
  q := 0.U

  for (i <- 0 until 32) {
    val element = getElement(io.x, i)
    val sign = getSign(element)
    val mantissa = getMantissa(element)
    val exp = element(30, 23)

    val qElement = Wire(UInt(4.W))
    when (anyNaNOrInf) {
      qElement := 0.U
    }.elsewhen (element === 0.U) {
      qElement := Cat(sign, 0.U(3.W))
    }.otherwise {
      val shiftedValue = element >> (shared + 23).asUInt(8.W)
      val roundedValue = (shiftedValue + 8.U).asUInt(32.W) >> 4.U
      val saturatedValue = Mux(roundedValue > 6.U, 6.U, Mux(roundedValue < -6.U, -6.U, roundedValue))
      qElement := Cat(sign, saturatedValue.asUInt(3.W))
    }

    q := q | (qElement << (i * 4).U)
  }

  io.scale := scale
  io.q := q
}